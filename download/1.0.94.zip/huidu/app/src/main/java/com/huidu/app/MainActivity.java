package com.huidu.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.NonNull;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Objects;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class MainActivity extends Activity
{
	private HttpURLConnection conn01,conn02;
	private boolean huidu = true;
	private boolean fanyi = true;
	private boolean movie = true;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
		}
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
		int option = getWindow().getDecorView().getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
		getWindow().getDecorView().setSystemUiVisibility(option);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			getWindow().setStatusBarColor(Color.TRANSPARENT);
		}
		setContentView(R.layout.main);

		final EditText ed01 = findViewById(R.id.ed01);
		final TextView tv01 = findViewById(R.id.tv01);
		final Button btn01 = findViewById(R.id.btn01);
		final Button btn02 = findViewById(R.id.btn02);
		final Button btn03 = findViewById(R.id.btn03);
		final Button btn04 = findViewById(R.id.btn04);
		final Button btn05 = findViewById(R.id.btn05);
		final Button btn06 = findViewById(R.id.btn06);
		final Button btn07 = findViewById(R.id.btn07);
		final Button btn08 = findViewById(R.id.btn08);
		final Button btn09 = findViewById(R.id.btn09);
		final Button btn10 = findViewById(R.id.btn10);
		final Button btn11 = findViewById(R.id.btn11);
		final Button btn12 = findViewById(R.id.btn12);
		final Button btn13 = findViewById(R.id.btn13);
		final Button btn14 = findViewById(R.id.btn14);
		final Button btn15 = findViewById(R.id.btn15);
		final Button btn16 = findViewById(R.id.btn16);
		final Button btn17 = findViewById(R.id.btn17);
		final Button btn18 = findViewById(R.id.btn18);
		final Button btn19 = findViewById(R.id.btn19);
		final Button btn20 = findViewById(R.id.btn20);
		final Button btn21 = findViewById(R.id.btn21);
		final Button btn22 = findViewById(R.id.btn22);
		final Button btn23 = findViewById(R.id.btn23);
		final Button btn24 = findViewById(R.id.btn24);
		final Button btn25 = findViewById(R.id.btn25);
		final Button btn26 = findViewById(R.id.btn26);
		final Button btn27 = findViewById(R.id.btn27);
		final Button btn28 = findViewById(R.id.btn28);
		final Button btn29 = findViewById(R.id.btn29);
		final Button btn30 = findViewById(R.id.btn30);
		final Button btn31 = findViewById(R.id.btn31);
		final Button btn32 = findViewById(R.id.btn32);
		final TableRow table01 = findViewById(R.id.table01);
		final TableRow table02 = findViewById(R.id.table02);
		final TableRow table03 = findViewById(R.id.table03);
		final TableRow table04 = findViewById(R.id.table04);
		final TableRow table05 = findViewById(R.id.table05);
		final TableRow table06 = findViewById(R.id.table06);
		final TableRow table07 = findViewById(R.id.table07);

		tv01.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v)
			{
				ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
				ClipData mClipData = ClipData.newPlainText("Label", tv01.getText().toString());
				if (cm != null) {
					cm.setPrimaryClip(mClipData);
				}
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						if (shuc.equals("1"))
						{
							tv01.setText("");
						}
					}};
				Bundle bd = new Bundle();
				bd.putString("content", "1");
				Message msg = new Message();
				msg.setData(bd);
				handler.sendMessage(msg);
			}});

		btn01.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){

					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						if (shuc.equals("1"))
						{
							if (huidu)
							{
								if (table01.getVisibility()==VISIBLE)
								{
									table01.setVisibility(GONE);
									table02.setVisibility(GONE);
								}
								if (table05.getVisibility()==VISIBLE)
								{
									table05.setVisibility(GONE);
									table06.setVisibility(GONE);
									fanyi = true;
								}
								if (table07.getVisibility()==VISIBLE)
								{
									table02.setVisibility(GONE);
									table07.setVisibility(GONE);
									movie = true;
								}
								table03.setVisibility(VISIBLE);
								table04.setVisibility(VISIBLE);
								huidu = false;
							}
							else
							{
								if (table05.getVisibility()==VISIBLE)
								{
									table05.setVisibility(GONE);
									table06.setVisibility(GONE);
									fanyi = true;
								}
								if (table07.getVisibility()==VISIBLE)
								{
									table02.setVisibility(GONE);
									table07.setVisibility(GONE);
									movie = true;
								}
								table03.setVisibility(GONE);
								table04.setVisibility(GONE);
								table01.setVisibility(VISIBLE);
								table02.setVisibility(VISIBLE);
								huidu = true;
							}
						}}
				};
				Bundle bd = new Bundle();
				bd.putString("content", "1");
				Message message = new Message();
				message.setData(bd);
				handler.sendMessage(message);
			}});

		btn02.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						if (shuc.equals("1"))
						{
							if (fanyi)
							{
								if (table01.getVisibility()==VISIBLE)
								{
									table01.setVisibility(GONE);
									table02.setVisibility(GONE);
								}
								if (table03.getVisibility()==VISIBLE)
								{
									table03.setVisibility(GONE);
									table04.setVisibility(GONE);
									huidu = true;
								}
								if (table07.getVisibility()==VISIBLE)
								{
									table02.setVisibility(GONE);
									table07.setVisibility(GONE);
									movie = true;
								}
								table05.setVisibility(VISIBLE);
								table06.setVisibility(VISIBLE);
								fanyi = false;
							}
							else
							{
								if (table03.getVisibility()==VISIBLE)
								{
									table03.setVisibility(GONE);
									table04.setVisibility(GONE);
									huidu = true;
								}
								if (table07.getVisibility()==VISIBLE)
								{
									table02.setVisibility(GONE);
									table07.setVisibility(GONE);
									movie = true;
								}
								table05.setVisibility(GONE);
								table06.setVisibility(GONE);
								table01.setVisibility(VISIBLE);
								table02.setVisibility(VISIBLE);
								fanyi = true;
							}
						}}
				};
				Bundle bd = new Bundle();
				bd.putString("content", "1");
				Message message = new Message();
				message.setData(bd);
				handler.sendMessage(message);
			}});

		btn03.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
						ed01.setText("");
					}
				};
				String sc = ed01.getText().toString();
				if (sc.length() <= 0)
				{
					ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
					if (manager != null && manager.hasPrimaryClip()) {
						ClipData data = manager.getPrimaryClip();
						if (data != null) {
							CharSequence addedText = data.getItemAt(0).getText();
							sc = String.valueOf(addedText);
						}
					}
				}
				Bundle bd = new Bundle();
				bd.putString("content", sc);
				Message message = new Message();
				message.setData(bd);
				handler.sendMessage(message);
				if (!sc.contains("http")) {
					if (sc.contains(".com") || sc.contains(".cn") || sc.contains(".edu") || sc.contains("cc") || sc.contains(".top") || sc.contains(".io") || sc.contains(".xyz") || sc.contains(".org") || sc.contains(".net"))
					{
						sc = "https://" + sc;
					}
					else
					{
						sc = "https://m.baidu.com/s?from=1022560v&word=" + sc;
					}}
				Intent intent = new Intent(MainActivity.this, WebActivity.class);
				intent.putExtra("jx", sc);
				startActivity(intent);
			}});

		btn04.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v)
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						if (shuc.equals("1"))
						{
							tv01.setText("");
							ed01.setText("");
						}}
				};
				Bundle bd = new Bundle();
				bd.putString("content", "1");
				Message message = new Message();
				message.setData(bd);
				handler.sendMessage(message);
			}});

		btn05.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				laJi();
			}
			private void laJi()
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
						ed01.setText("");
					}
				};
				new Thread(new Runnable(){
					@Override
					public void run()
					{
						try
						{
							String sc = ed01.getText().toString();
							String ljApi = "https://quark.sm.cn/api/rest?method=sc.operation_sorting_category&app_chain_name=waste_classify&q=";
							if (sc.length() <= 0)
							{
								ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								if (manager != null && manager.hasPrimaryClip()) {
									ClipData data = manager.getPrimaryClip();
									if (data != null) {
										CharSequence addedText = data.getItemAt(0).getText();
										sc = String.valueOf(addedText);
									}
								}
							}
							URL url=new URL(ljApi + URLEncoder.encode(sc, "UTF-8"));
							conn01 = (HttpURLConnection)url.openConnection();
							conn01.setConnectTimeout(5000);
							if (conn01.getResponseCode() == 200)
							{
								InputStream ipSt01 = conn01.getInputStream();
								BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
								String result01 = br01.readLine();
								JSONObject json01 = new JSONObject(result01);
								br01.close();
								ipSt01.close();
								conn01.disconnect();
								JSONObject dataObject = json01.getJSONObject("data");
								String typeStr = dataObject.getString("waste_type");
								String endStr = typeStr + "\n" + "\n" + sc;
								Bundle bd = new Bundle();
								bd.putString("content", endStr);
								Message message = new Message();
								message.setData(bd);
								handler.sendMessage(message);
							}
							else
							{
								conn01.disconnect();
							}} catch (Exception e)
							{
								e.printStackTrace();
							}
					}}).start();
			}});

		btn06.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				kuaiDi();
			}
			private void kuaiDi()
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
						ed01.setText("");
					}
				};
				new Thread(new Runnable(){
					@Override
					public void run()
					{
						try
						{
							String sc = ed01.getText().toString();
							String kdApi = "https://api.vvhan.com/api/kuaidi?hao=";
							if (sc.length() <= 0)
							{
								ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								if (manager != null && manager.hasPrimaryClip()) {
									ClipData data = manager.getPrimaryClip();
									if (data != null) {
										CharSequence addedText = data.getItemAt(0).getText();
										sc = String.valueOf(addedText);
									}
								}
							}
							else
							{
								ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								ClipData mClipData = ClipData.newPlainText("Label", sc);
								if (cm != null) {
									cm.setPrimaryClip(mClipData);
								}
							}
							URL url=new URL(kdApi + URLEncoder.encode(sc, "UTF-8"));
							conn01 = (HttpURLConnection)url.openConnection();
							conn01.setConnectTimeout(5000);
							if (conn01.getResponseCode() == 200)
							{
								InputStream ipSt01 = conn01.getInputStream();
								BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
								String result01 = br01.readLine();
								JSONObject json01 = new JSONObject(result01);
								br01.close();
								ipSt01.close();
								conn01.disconnect();
								String gsStr = json01.getString("company");
								String ztStr = json01.getString("status");
								JSONArray infoArray = json01.getJSONArray("info");
								JSONObject infooneObject = infoArray.getJSONObject(0);
								String conStr = infooneObject.getString("context");
								String timeStr = infooneObject.getString("time");
								String endStr = conStr + "\n" + "\n" + timeStr + "\n" + "\n" + gsStr + " - " + ztStr;
								Bundle bd = new Bundle();
								bd.putString("content", endStr);
								Message message = new Message();
								message.setData(bd);
								handler.sendMessage(message);
							}
							else
							{
								conn01.disconnect();
							}} catch (Exception e)
							{
								e.printStackTrace();
							}
					}}).start();
			}});

		btn07.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				suoDw();
			}
			private void suoDw()
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
						ed01.setText("");
					}
				};
				new Thread(new Runnable(){
					@Override
					public void run()
					{
						try
						{
							String sc = ed01.getText().toString();
							String suoApi = "https://xiaobeiit.cn/api/ys.php?url=";
							if (sc.length() <= 0)
							{
								ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								if (manager != null && manager.hasPrimaryClip()) {
									ClipData data = manager.getPrimaryClip();
									if (data != null) {
										CharSequence addedText = data.getItemAt(0).getText();
										sc = String.valueOf(addedText);
									}
								}
							}
							URL url=new URL(suoApi + URLEncoder.encode(sc, "UTF-8"));
							conn01 = (HttpURLConnection)url.openConnection();
							conn01.setConnectTimeout(5000);
							if (conn01.getResponseCode() == 200)
							{
								InputStream ipSt01 = conn01.getInputStream();
								BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
								String suoDw = br01.readLine();
								br01.close();
								ipSt01.close();
								conn01.disconnect();
								String endStr = sc + "\n" + "\n" + suoDw;
								Bundle bd = new Bundle();
								bd.putString("content", endStr);
								Message message = new Message();
								message.setData(bd);
								handler.sendMessage(message);
								ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								ClipData mClipData = ClipData.newPlainText("Label", suoDw);
								if (cm != null) {
									cm.setPrimaryClip(mClipData);
								}
							}
							else
							{
								conn01.disconnect();
							}}
						catch (Exception e)
						{
							e.printStackTrace();
						}
					}}).start();
			}});

		btn08.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				lanDw();
			}
			private void lanDw()
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
						ed01.setText("");
					}
				};
				new Thread(new Runnable(){
					@Override
					public void run()
					{
						try
						{
							String longsc = ed01.getText().toString();
							if (longsc.length() <= 0)
							{
								ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								if (manager != null && manager.hasPrimaryClip()) {
									ClipData data = manager.getPrimaryClip();
									if (data != null) {
										CharSequence addedText = data.getItemAt(0).getText();
										longsc = String.valueOf(addedText);
									}
								}
							}
							String sc = longsc.substring(longsc.lastIndexOf("/")+1);
							String lanApi = "https://xiaobeiit.cn/lanzou/?url=";
							URL url=new URL(lanApi + URLEncoder.encode(sc, "UTF-8"));
							conn01 = (HttpURLConnection)url.openConnection();
							conn01.setConnectTimeout(5000);
							if (conn01.getResponseCode() == 200)
							{
								InputStream ipSt01 = conn01.getInputStream();
								BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
								String result01 = br01.readLine();
								JSONObject json01 = new JSONObject(result01);
								br01.close();
								ipSt01.close();
								conn01.disconnect();
								JSONObject textObject = json01.getJSONObject("text");
								String nameStr = textObject.getString("name");
								String namecopyStr = nameStr.substring(0, nameStr.lastIndexOf("."));
								String sizeStr = textObject.getString("size");
								String timeStr = textObject.getString("time");
								JSONObject downObject = json01.getJSONObject("down");
								String lanDw = downObject.getString("url_dom");
								String endStr = longsc + "\n" + "\n" + "File Nmae : " + nameStr + "\n" + "\n" + "Share Time : " + timeStr + "\n" + "\n" + "File Size : " + sizeStr;
								if (lanDw.length() > 0)
								{
									Bundle bd = new Bundle();
									bd.putString("content", endStr);
									Message message = new Message();
									message.setData(bd);
									handler.sendMessage(message);
								}
								ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								ClipData mClipData = ClipData.newPlainText("Label", namecopyStr);
								if (cm != null) {
									cm.setPrimaryClip(mClipData);
								}
								Intent intent = new Intent(MainActivity.this, WebActivity.class);
								intent.putExtra("jx", lanDw);
								startActivity(intent);
							}
							else
							{
								conn01.disconnect();
							}} catch (Exception e)
							{
								e.printStackTrace();
							}
					}}).start();
			}});

		btn09.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				mgDw();
			}
			private void mgDw()
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
						ed01.setText("");
					}
				};
				new Thread(new Runnable(){
					@Override
					public void run()
					{
						try
						{
							String sc = ed01.getText().toString();
							String msApi = "http://music.jsososo.com/apiM/search?type=song&pageno=1&keyword=";
							if (sc.length() <= 0)
							{
								ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								if (manager != null && manager.hasPrimaryClip()) {
									ClipData data = manager.getPrimaryClip();
									if (data != null) {
										CharSequence addedText = data.getItemAt(0).getText();
										sc = String.valueOf(addedText);
									}
								}
							}
							URL url=new URL(msApi + URLEncoder.encode(sc, "UTF-8"));
							conn01 = (HttpURLConnection)url.openConnection();
							conn01.setConnectTimeout(5000);
							if (conn01.getResponseCode() == 200)
							{
								InputStream ipSt01 = conn01.getInputStream();
								BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
								String result01 = br01.readLine();
								JSONObject json01 = new JSONObject(result01);
								br01.close();
								ipSt01.close();
								conn01.disconnect();
								Bundle bd = new Bundle();
								bd.putString("content", sc);
								Message message = new Message();
								message.setData(bd);
								handler.sendMessage(message);
								JSONObject dataObject = json01.getJSONObject("data");
								JSONArray listArray = dataObject.getJSONArray("list");
								JSONObject listoneObject = listArray.getJSONObject(0);
								String id = listoneObject.getString("cid");
								String gid=listoneObject.getString("id");
								String mf = "http://api.migu.jsososo.com/song/url?cid=" + id + "&id=" + gid;
								String mcStr = listoneObject.getString("name");
								JSONArray artArray = listoneObject.getJSONArray("artists");
								JSONObject artoneObject = artArray.getJSONObject(0);
								String gsStr = artoneObject.getString("name");
								String endStr = gsStr + "-" + mcStr;
								ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								ClipData mClipData = ClipData.newPlainText("Label", endStr);
								if (cm != null) {
									cm.setPrimaryClip(mClipData);
								}
								try
								{
									URL ur=new URL(mf);
									conn02 = (HttpURLConnection)ur.openConnection();
									conn02.setConnectTimeout(5000);
									if (conn02.getResponseCode() == 200)
									{
										InputStream ipSt02 = conn02.getInputStream();
										BufferedReader br02 = new BufferedReader(new InputStreamReader(ipSt02));
										String result02 = br02.readLine();
										JSONObject json02 = new JSONObject(result02);
										br02.close();
										ipSt02.close();
										conn02.disconnect();
										JSONObject daObject = json02.getJSONObject("data");
										String mgDw = daObject.getString("flac");
										Intent intent = new Intent(MainActivity.this, WebActivity.class);
										intent.putExtra("jx", mgDw);
										startActivity(intent);
									}
									else
									{
										conn02.disconnect();
									}} catch (Exception e)
									{
										e.printStackTrace();
									}
							}
							else
							{
								conn01.disconnect();
							}} catch (Exception e)
							{
								e.printStackTrace();
							}
					}}).start();
			}});

		btn10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				qieDw();
			}

			private void qieDw()
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
						ed01.setText("");
					}
				};
				new Thread(new Runnable(){
					@Override
					public void run()
					{
						try
						{
							String sc = ed01.getText().toString();
							String qsApi = "https://api.qq.jsososo.com/search?key=";
							if (sc.length() <= 0)
							{
								ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								if (manager != null && manager.hasPrimaryClip()) {
									ClipData data = manager.getPrimaryClip();
									if (data != null) {
										CharSequence addedText = data.getItemAt(0).getText();
										sc = String.valueOf(addedText);
									}
								}
							}
							URL url=new URL(qsApi + URLEncoder.encode(sc, "UTF-8"));
							conn01 = (HttpURLConnection)url.openConnection();
							conn01.setConnectTimeout(5000);
							if (conn01.getResponseCode() == 200)
							{
								InputStream ipSt01 = conn01.getInputStream();
								BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
								String result01 = br01.readLine();
								JSONObject json01 = new JSONObject(result01);
								br01.close();
								ipSt01.close();
								conn01.disconnect();
								Bundle bd = new Bundle();
								bd.putString("content", sc);
								Message message = new Message();
								message.setData(bd);
								handler.sendMessage(message);
								JSONObject dataObject = json01.getJSONObject("data");
								JSONArray listArray = dataObject.getJSONArray("list");
								JSONObject listoneObject = listArray.getJSONObject(0);
								String id = listoneObject.getString("songmid");
								String mcStr = listoneObject.getString("songname");
								String qf = "https://api.qq.jsososo.com/song/url?id=" + id + "&type=flac";
								JSONArray artArray = listoneObject.getJSONArray("singer");
								JSONObject artoneObject = artArray.getJSONObject(0);
								String gsStr = artoneObject.getString("name");
								String endStr = gsStr + "-" + mcStr;
								ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								ClipData mClipData = ClipData.newPlainText("Label", endStr);
								if (cm != null) {
									cm.setPrimaryClip(mClipData);
								}
								try
								{
									URL ur=new URL(qf);
									conn02 = (HttpURLConnection)ur.openConnection();
									conn02.setConnectTimeout(5000);
									if (conn02.getResponseCode() == 200)
									{
										InputStream ipSt02 = conn02.getInputStream();
										BufferedReader br02 = new BufferedReader(new InputStreamReader(ipSt02));
										String result02 = br02.readLine();
										JSONObject json02 = new JSONObject(result02);
										br02.close();
										ipSt02.close();
										conn02.disconnect();
										String qieDw = json02.getString("data");
										Intent intent = new Intent(MainActivity.this, WebActivity.class);
										intent.putExtra("jx", qieDw);
										startActivity(intent);
									}
									else
									{
										conn02.disconnect();
									}} catch (Exception e)
									{
										e.printStackTrace();
									}
							}
							else
							{
								conn01.disconnect();
							}} catch (Exception e)
							{
								e.printStackTrace();
							}
					}}).start();
			}});

		btn11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				ycDw();
			}

			private void ycDw()
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
						ed01.setText("");
					}
				};
				new Thread(new Runnable(){
					@Override
					public void run()
					{
						try
						{
							String sc = ed01.getText().toString();
							if (sc.length() <= 0)
							{
								ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								if (manager != null && manager.hasPrimaryClip()) {
									ClipData data = manager.getPrimaryClip();
									if (data != null) {
										CharSequence addedText = data.getItemAt(0).getText();
										sc = String.valueOf(addedText);
									}
								}
							}
							String ycApi = "https://music.jeeas.cn/v1/search?s=";
							URL url=new URL(ycApi + URLEncoder.encode(sc, "UTF-8") + "&from=music");
							conn01 = (HttpURLConnection)url.openConnection();
							conn01.setConnectTimeout(5000);
							if (conn01.getResponseCode() == 200)
							{
								InputStream ipSt01 = conn01.getInputStream();
								BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
								String result01 = br01.readLine();
								JSONObject json01 = new JSONObject(result01);
								br01.close();
								ipSt01.close();
								conn01.disconnect();
								Bundle bd = new Bundle();
								bd.putString("content", sc);
								Message message = new Message();
								message.setData(bd);
								handler.sendMessage(message);
								JSONObject resultObject = json01.getJSONObject("result");
								JSONArray songsArray = resultObject.getJSONArray("songs");
								JSONObject songoneObject = songsArray.getJSONObject(0);
								String mcStr = songoneObject.getString("name");
								JSONArray artArray = songoneObject.getJSONArray("ar");
								JSONObject artoneObject = artArray.getJSONObject(0);
								String gsStr = artoneObject.getString("name");
								String endStr = gsStr + "-" + mcStr;
								ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								ClipData mClipData = ClipData.newPlainText("Label", endStr);
								if (cm != null) {
									cm.setPrimaryClip(mClipData);
								}
								String ycSc = "http://tool.liumingye.cn/music/?page=audioPage&type=YQD&name=" + gsStr + mcStr;
								Intent intent = new Intent(MainActivity.this, WebActivity.class);
								intent.putExtra("jx", ycSc);
								startActivity(intent);
							}
							else
							{
								conn01.disconnect();
							}} catch (Exception e)
							{
								e.printStackTrace();
							}
					}}).start();
			}});

		btn12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						if (shuc.equals("1"))
						{
							if (movie)
							{
								table07.setVisibility(VISIBLE);
								table01.setVisibility(GONE);
								movie = false;
							}
							else
							{
								table01.setVisibility(VISIBLE);
								table07.setVisibility(GONE);
								movie = true;
							}
						}}
				};
				Bundle bd = new Bundle();
				bd.putString("content", "1");
				Message message = new Message();
				message.setData(bd);
				handler.sendMessage(message);
			}});

		btn13.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				WebActivity.skip(MainActivity.this, "https://xiaobeiit.gitee.io/soft.html");
			}});

		btn14.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				WebActivity.skip(MainActivity.this, "https://xiaobeiit.gitee.io/shisuiji.html");
			}});

		btn15.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				WebActivity.skip(MainActivity.this, "https://xiaobeiit.gitee.io/huidupro.html");
			}});

		btn16.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				WebActivity.skip(MainActivity.this, "https://xiaobeiit.gitee.io");
			}});

		btn17.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				WebActivity.skip(MainActivity.this, "https://xiaobeiit.gitee.io/update.html");
			}});

		btn18.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				WebActivity.skip(MainActivity.this, "https://xiaobeiit.gitee.io/huidu/android/nnxw.html");
			}});

		btn19.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				try {
					joinQQGroup("VglHAPvxiNNFWXO0MrqcTxjdKdQzl0Bb");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}});

		btn20.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				WebActivity.skip(MainActivity.this, "https://xiaobeiit.gitee.io/Reward.png");
			}});

		btn21.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				fanYi();
			}
			private void fanYi()
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
					}
				};
				new Thread(new Runnable(){
					@Override
					public void run()
					{
						try
						{
							String sc = ed01.getText().toString();
							String fyApi = "https://xiaobeiit.cn/api/fy.php?w=";
							if (sc.length() <= 0)
							{
								ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								if (manager != null && manager.hasPrimaryClip()) {
									ClipData data = manager.getPrimaryClip();
									if (data != null) {
										CharSequence addedText = data.getItemAt(0).getText();
										sc = String.valueOf(addedText);
									}
								}
							}
							URL url=new URL(fyApi + URLEncoder.encode(sc, "UTF-8") + "&t=zh");
							conn01 = (HttpURLConnection)url.openConnection();
							conn01.setConnectTimeout(5000);
							if (conn01.getResponseCode() == 200)
							{
								InputStream ipSt01 = conn01.getInputStream();
								BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
								String result01 = br01.readLine();
								br01.close();
								ipSt01.close();
								conn01.disconnect();
								String shuchu = sc + "\n" + "\n" + result01;
								Bundle bd = new Bundle();
								bd.putString("content", shuchu);
								Message message = new Message();
								message.setData(bd);
								handler.sendMessage(message);
								ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								ClipData mClipData = ClipData.newPlainText("Label", result01);
								if (cm != null) {
									cm.setPrimaryClip(mClipData);
								}
							}
							else
							{
								conn01.disconnect();
							}}
						catch (Exception e)
						{
							e.printStackTrace();
						}
					}}).start();
			}});

		btn22.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				fanYi();
			}
			private void fanYi()
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
					}
				};
				new Thread(new Runnable(){
					@Override
					public void run()
					{
						try
						{
							String sc = ed01.getText().toString();
							String fyApi = "https://xiaobeiit.cn/api/fy.php?w=";
							if (sc.length() <= 0)
							{
								ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								if (manager != null && manager.hasPrimaryClip()) {
									ClipData data = manager.getPrimaryClip();
									if (data != null) {
										CharSequence addedText = data.getItemAt(0).getText();
										sc = String.valueOf(addedText);
									}
								}
							}
							URL url=new URL(fyApi + URLEncoder.encode(sc, "UTF-8") + "&t=en");
							conn01 = (HttpURLConnection)url.openConnection();
							conn01.setConnectTimeout(5000);
							if (conn01.getResponseCode() == 200)
							{
								InputStream ipSt01 = conn01.getInputStream();
								BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
								String result01 = br01.readLine();
								br01.close();
								ipSt01.close();
								conn01.disconnect();
								String shuchu = sc + "\n" + "\n" + result01;
								Bundle bd = new Bundle();
								bd.putString("content", shuchu);
								Message message = new Message();
								message.setData(bd);
								handler.sendMessage(message);
								ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								ClipData mClipData = ClipData.newPlainText("Label", result01);
								if (cm != null) {
									cm.setPrimaryClip(mClipData);
								}
							}
							else
							{
								conn01.disconnect();
							}}
						catch (Exception e)
						{
							e.printStackTrace();
						}
					}}).start();
			}});

		btn23.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				fanYi();
			}
			private void fanYi()
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
					}
				};
				new Thread(new Runnable(){
					@Override
					public void run()
					{
						try
						{
							String sc = ed01.getText().toString();
							String fyApi = "https://xiaobeiit.cn/api/fy.php?w=";
							if (sc.length() <= 0)
							{
								ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								if (manager != null && manager.hasPrimaryClip()) {
									ClipData data = manager.getPrimaryClip();
									if (data != null) {
										CharSequence addedText = data.getItemAt(0).getText();
										sc = String.valueOf(addedText);
									}
								}
							}
							URL url=new URL(fyApi + URLEncoder.encode(sc, "UTF-8") + "&t=jp");
							conn01 = (HttpURLConnection)url.openConnection();
							conn01.setConnectTimeout(5000);
							if (conn01.getResponseCode() == 200)
							{
								InputStream ipSt01 = conn01.getInputStream();
								BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
								String result01 = br01.readLine();
								br01.close();
								ipSt01.close();
								conn01.disconnect();
								String shuchu = sc + "\n" + "\n" + result01;
								Bundle bd = new Bundle();
								bd.putString("content", shuchu);
								Message message = new Message();
								message.setData(bd);
								handler.sendMessage(message);
								ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								ClipData mClipData = ClipData.newPlainText("Label", result01);
								if (cm != null) {
									cm.setPrimaryClip(mClipData);
								}
							}
							else
							{
								conn01.disconnect();
							}}
						catch (Exception e)
						{
							e.printStackTrace();
						}
					}}).start();
			}});

		btn24.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				fanYi();
			}
			private void fanYi()
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
					}
				};
				new Thread(new Runnable(){
					@Override
					public void run()
					{
						try
						{
							String sc = ed01.getText().toString();
							String fyApi = "https://xiaobeiit.cn/api/fy.php?w=";
							if (sc.length() <= 0)
							{
								ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								if (manager != null && manager.hasPrimaryClip()) {
									ClipData data = manager.getPrimaryClip();
									if (data != null) {
										CharSequence addedText = data.getItemAt(0).getText();
										sc = String.valueOf(addedText);
									}
								}
							}
							URL url=new URL(fyApi + URLEncoder.encode(sc, "UTF-8") + "&t=kor");
							conn01 = (HttpURLConnection)url.openConnection();
							conn01.setConnectTimeout(5000);
							if (conn01.getResponseCode() == 200)
							{
								InputStream ipSt01 = conn01.getInputStream();
								BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
								String result01 = br01.readLine();
								br01.close();
								ipSt01.close();
								conn01.disconnect();
								String shuchu = sc + "\n" + "\n" + result01;
								Bundle bd = new Bundle();
								bd.putString("content", shuchu);
								Message message = new Message();
								message.setData(bd);
								handler.sendMessage(message);
								ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								ClipData mClipData = ClipData.newPlainText("Label", result01);
								if (cm != null) {
									cm.setPrimaryClip(mClipData);
								}
							}
							else
							{
								conn01.disconnect();
							}}
						catch (Exception e)
						{
							e.printStackTrace();
						}
					}}).start();
			}});

		btn25.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				fanYi();
			}
			private void fanYi()
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
					}
				};
				new Thread(new Runnable(){
					@Override
					public void run()
					{
						try
						{
							String sc = ed01.getText().toString();
							String fyApi = "https://xiaobeiit.cn/api/fy.php?w=";
							if (sc.length() <= 0)
							{
								ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								if (manager != null && manager.hasPrimaryClip()) {
									ClipData data = manager.getPrimaryClip();
									if (data != null) {
										CharSequence addedText = data.getItemAt(0).getText();
										sc = String.valueOf(addedText);
									}
								}
							}
							URL url=new URL(fyApi + URLEncoder.encode(sc, "UTF-8") + "&t=fra");
							conn01 = (HttpURLConnection)url.openConnection();
							conn01.setConnectTimeout(5000);
							if (conn01.getResponseCode() == 200)
							{
								InputStream ipSt01 = conn01.getInputStream();
								BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
								String result01 = br01.readLine();
								br01.close();
								ipSt01.close();
								conn01.disconnect();
								String shuchu = sc + "\n" + "\n" + result01;
								Bundle bd = new Bundle();
								bd.putString("content", shuchu);
								Message message = new Message();
								message.setData(bd);
								handler.sendMessage(message);
								ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								ClipData mClipData = ClipData.newPlainText("Label", result01);
								if (cm != null) {
									cm.setPrimaryClip(mClipData);
								}
							}
							else
							{
								conn01.disconnect();
							}}
						catch (Exception e)
						{
							e.printStackTrace();
						}
					}}).start();
			}});

		btn26.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				fanYi();
			}
			private void fanYi()
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
					}
				};
				new Thread(new Runnable(){
					@Override
					public void run()
					{
						try
						{
							String sc = ed01.getText().toString();
							String fyApi = "https://xiaobeiit.cn/api/fy.php?w=";
							if (sc.length() <= 0)
							{
								ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								if (manager != null && manager.hasPrimaryClip()) {
									ClipData data = manager.getPrimaryClip();
									if (data != null) {
										CharSequence addedText = data.getItemAt(0).getText();
										sc = String.valueOf(addedText);
									}
								}
							}
							URL url=new URL(fyApi + URLEncoder.encode(sc, "UTF-8") + "&t=th");
							conn01 = (HttpURLConnection)url.openConnection();
							conn01.setConnectTimeout(5000);
							if (conn01.getResponseCode() == 200)
							{
								InputStream ipSt01 = conn01.getInputStream();
								BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
								String result01 = br01.readLine();
								br01.close();
								ipSt01.close();
								conn01.disconnect();
								String shuchu = sc + "\n" + "\n" + result01;
								Bundle bd = new Bundle();
								bd.putString("content", shuchu);
								Message message = new Message();
								message.setData(bd);
								handler.sendMessage(message);
								ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								ClipData mClipData = ClipData.newPlainText("Label", result01);
								if (cm != null) {
									cm.setPrimaryClip(mClipData);
								}
							}
							else
							{
								conn01.disconnect();
							}}
						catch (Exception e)
						{
							e.printStackTrace();
						}
					}}).start();
			}});

		btn27.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				fanYi();
			}
			private void fanYi()
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
					}
				};
				new Thread(new Runnable(){
					@Override
					public void run()
					{
						try
						{
							String sc = ed01.getText().toString();
							String fyApi = "https://xiaobeiit.cn/api/fy.php?w=";
							if (sc.length() <= 0)
							{
								ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								if (manager != null && manager.hasPrimaryClip()) {
									ClipData data = manager.getPrimaryClip();
									if (data != null) {
										CharSequence addedText = data.getItemAt(0).getText();
										sc = String.valueOf(addedText);
									}
								}
							}
							URL url=new URL(fyApi + URLEncoder.encode(sc, "UTF-8") + "&t=de");
							conn01 = (HttpURLConnection)url.openConnection();
							conn01.setConnectTimeout(5000);
							if (conn01.getResponseCode() == 200)
							{
								InputStream ipSt01 = conn01.getInputStream();
								BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
								String result01 = br01.readLine();
								br01.close();
								ipSt01.close();
								conn01.disconnect();
								String shuchu = sc + "\n" + "\n" + result01;
								Bundle bd = new Bundle();
								bd.putString("content", shuchu);
								Message message = new Message();
								message.setData(bd);
								handler.sendMessage(message);
								ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								ClipData mClipData = ClipData.newPlainText("Label", result01);
								if (cm != null) {
									cm.setPrimaryClip(mClipData);
								}
							}
							else
							{
								conn01.disconnect();
							}}
						catch (Exception e)
						{
							e.printStackTrace();
						}
					}}).start();
			}});

		btn28.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				fanYi();
			}
			private void fanYi()
			{
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
					}
				};
				new Thread(new Runnable(){
					@Override
					public void run()
					{
						try
						{
							String sc = ed01.getText().toString();
							String fyApi = "https://xiaobeiit.cn/api/fy.php?w=";
							if (sc.length() <= 0)
							{
								ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								if (manager != null && manager.hasPrimaryClip()) {
									ClipData data = manager.getPrimaryClip();
									if (data != null) {
										CharSequence addedText = data.getItemAt(0).getText();
										sc = String.valueOf(addedText);
									}
								}
							}
							URL url=new URL(fyApi + URLEncoder.encode(sc, "UTF-8") + "&t=ru");
							conn01 = (HttpURLConnection)url.openConnection();
							conn01.setConnectTimeout(5000);
							if (conn01.getResponseCode() == 200)
							{
								InputStream ipSt01 = conn01.getInputStream();
								BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
								String result01 = br01.readLine();
								br01.close();
								ipSt01.close();
								conn01.disconnect();
								String shuchu = sc + "\n" + "\n" + result01;
								Bundle bd = new Bundle();
								bd.putString("content", shuchu);
								Message message = new Message();
								message.setData(bd);
								handler.sendMessage(message);
								ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								ClipData mClipData = ClipData.newPlainText("Label", result01);
								if (cm != null) {
									cm.setPrimaryClip(mClipData);
								}
							}
							else
							{
								conn01.disconnect();
							}}
						catch (Exception e)
						{
							e.printStackTrace();
						}
					}}).start();
			}});

		btn29.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
						ed01.setText("");
					}
				};
				String sc = ed01.getText().toString();
				if (sc.length() <= 0)
				{
					ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
					if (manager != null && manager.hasPrimaryClip()) {
						ClipData data = manager.getPrimaryClip();
						if (data != null) {
							CharSequence addedText = data.getItemAt(0).getText();
							sc = String.valueOf(addedText);
						}
					}
				}
				else
				{
					ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
					ClipData mClipData = ClipData.newPlainText("Label", sc);
					if (cm != null) {
						cm.setPrimaryClip(mClipData);
					}
				}
				String scjump = "https://search.youku.com/search_video?keyword=" + sc;
				Bundle bd = new Bundle();
				bd.putString("content", sc);
				Message message = new Message();
				message.setData(bd);
				handler.sendMessage(message);
				Intent intent = new Intent(MainActivity.this, WebActivity.class);
				intent.putExtra("jx", scjump);
				startActivity(intent);}});

		btn30.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
						ed01.setText("");
					}
				};
				String sc = ed01.getText().toString();
				if (sc.length() <= 0)
				{
					ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
					if (manager != null && manager.hasPrimaryClip()) {
						ClipData data = manager.getPrimaryClip();
						if (data != null) {
							CharSequence addedText = data.getItemAt(0).getText();
							sc = String.valueOf(addedText);
						}
					}
				}
				else
				{
					ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
					ClipData mClipData = ClipData.newPlainText("Label", sc);
					if (cm != null) {
						cm.setPrimaryClip(mClipData);
					}
				}
				String scjump = "https://m.iqiyi.com/search.html?key=" + sc;
				Bundle bd = new Bundle();
				bd.putString("content", sc);
				Message message = new Message();
				message.setData(bd);
				handler.sendMessage(message);
				Intent intent = new Intent(MainActivity.this, WebActivity.class);
				intent.putExtra("jx", scjump);
				startActivity(intent);}});

		btn31.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
						ed01.setText("");
					}
				};
				String sc = ed01.getText().toString();
				if (sc.length() <= 0)
				{
					ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
					if (manager != null && manager.hasPrimaryClip()) {
						ClipData data = manager.getPrimaryClip();
						if (data != null) {
							CharSequence addedText = data.getItemAt(0).getText();
							sc = String.valueOf(addedText);
						}
					}
				}
				else
				{
					ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
					ClipData mClipData = ClipData.newPlainText("Label", sc);
					if (cm != null) {
						cm.setPrimaryClip(mClipData);
					}
				}
				String scjump = "http://m.v.qq.com/search.html?keyWord=" + sc;
				Bundle bd = new Bundle();
				bd.putString("content", sc);
				Message message = new Message();
				message.setData(bd);
				handler.sendMessage(message);
				Intent intent = new Intent(MainActivity.this, WebActivity.class);
				intent.putExtra("jx", scjump);
				startActivity(intent);}});

		btn32.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				if (imm != null && imm.isActive()) {
					imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
					ed01.clearFocus();
				}
				@SuppressLint("HandlerLeak") final Handler handler = new Handler(){
					@Override
					public void handleMessage(@NonNull Message msg)
					{
						super.handleMessage(msg);
						String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
						tv01.setText(shuc);
						ed01.setText("");
					}
				};
				String sc = ed01.getText().toString();
				if (sc.length() <= 0)
				{
					ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
					if (manager != null && manager.hasPrimaryClip()) {
						ClipData data = manager.getPrimaryClip();
						if (data != null) {
							CharSequence addedText = data.getItemAt(0).getText();
							sc = String.valueOf(addedText);
						}
					}
				}
				else
				{
					ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
					ClipData mClipData = ClipData.newPlainText("Label", sc);
					if (cm != null) {
						cm.setPrimaryClip(mClipData);
					}
				}
				String scjump = "https://m.mgtv.com/so/?k=" + sc;
				Bundle bd = new Bundle();
				bd.putString("content", sc);
				Message message = new Message();
				message.setData(bd);
				handler.sendMessage(message);
				Intent intent = new Intent(MainActivity.this, WebActivity.class);
				intent.putExtra("jx", scjump);
				startActivity(intent);}});
	}
	public void joinQQGroup(String key){
		Intent intent = new Intent();
		intent.setData(Uri.parse("mqqopensdkapi://bizAgent/qm/qr?url=http%3A%2F%2Fqm.qq.com%2Fcgi-bin%2Fqm%2Fqr%3Ffrom%3Dapp%26p%3Dandroid%26k%3D" + key));
		startActivity(intent);
	}
}