package com.huidu.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.DownloadListener;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Objects;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class WebActivity extends Activity
{
  private WebView wv;
  private FrameLayout vc;
  private String webViewUrl;
  private boolean show = true;
  private boolean toum = true;
  private boolean zhuom = true;
  private boolean erji = true;
  private HttpURLConnection conn01;
  @SuppressLint("SetJavaScriptEnabled")
  @Override
  public void onCreate(Bundle savedInstanceState)
  {
	super.onCreate(savedInstanceState);
	getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
	  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
		  getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
	  }
	  getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
	int option = getWindow().getDecorView().getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
	getWindow().getDecorView().setSystemUiVisibility(option);
	  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
		  getWindow().setStatusBarColor(Color.TRANSPARENT);
	  }
	  setContentView(R.layout.browser);
	wv = findViewById(R.id.webView);
	vc = findViewById(R.id.videoContainer);
	final Button btn01 = findViewById(R.id.btn01);
	final Button btn02 = findViewById(R.id.btn02);
	final Button btn03 = findViewById(R.id.btn03);
	final Button btn04 = findViewById(R.id.btn04);
	final Button btn05 = findViewById(R.id.btn05);
	final Button btn06 = findViewById(R.id.btn06);
	final Button btn07 = findViewById(R.id.btn07);
	final Button btn08 = findViewById(R.id.btn08);
	final Button btn09 = findViewById(R.id.btn09);
	final Button btn10 = findViewById(R.id.btn10);
	final Button btn11 = findViewById(R.id.btn11);

	final String azua = wv.getSettings().getUserAgentString();

	getData();
	initViews();
	loadData();
	mvUrl();

	getDataFromBrowser(getIntent());
	handleSendText(getIntent());
	Intent intent = getIntent();
	String action = intent.getAction();
	String type = intent.getType();

	btn01.setOnClickListener(new View.OnClickListener() {
		@Override
		public void onClick(View v)
		{
		  if (show)
		  {
			btn02.setVisibility(VISIBLE);
			btn03.setVisibility(VISIBLE);
			btn04.setVisibility(VISIBLE);
			btn05.setVisibility(VISIBLE);
			btn06.setVisibility(VISIBLE);
			btn07.setVisibility(VISIBLE);
			btn08.setVisibility(VISIBLE);
			show = false;
		  }
		  else
		  {
			btn02.setVisibility(GONE);
			btn03.setVisibility(GONE);
			btn04.setVisibility(GONE);
			btn05.setVisibility(GONE);
			btn06.setVisibility(GONE);
			btn07.setVisibility(GONE);
			btn08.setVisibility(GONE);
			if (btn09.getVisibility() == VISIBLE)
			{
			  btn09.setVisibility(GONE);
			}
			if (btn10.getVisibility() == VISIBLE)
			{
			  btn10.setVisibility(GONE);
			}
			if (btn11.getVisibility() == VISIBLE)
			{
			  btn11.setVisibility(GONE);
			}
			show = true;
		  }
		}});

	btn01.setOnLongClickListener(new View.OnLongClickListener(){
		@Override
		public boolean onLongClick(View v)
		{
		  if (toum)
		  {
			btn01.setBackgroundResource(R.drawable.btntm);
			toum = false;
		  }
		  else
		  {
			btn01.setBackgroundResource(R.drawable.btnqj);
			toum = true;
		  }
		  return true;
		}
	  });

	btn02.setOnClickListener(new View.OnClickListener() {
		@Override
		public void onClick(View v)
		{
		  btn02.setVisibility(GONE);
		  btn03.setVisibility(GONE);
		  btn04.setVisibility(GONE);
		  btn05.setVisibility(GONE);
		  btn06.setVisibility(GONE);
		  btn07.setVisibility(GONE);
		  btn08.setVisibility(GONE);
		  show = true;
		  ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
		  ClipData mClipData = ClipData.newPlainText("Label", wv.getUrl());
			if (cm != null) {
				cm.setPrimaryClip(mClipData);
			}
		}});

	btn03.setOnClickListener(new View.OnClickListener() {
		@Override
		public void onClick(View v)
		{
		  btn02.setVisibility(GONE);
		  btn03.setVisibility(GONE);
		  btn04.setVisibility(GONE);
		  btn05.setVisibility(GONE);
		  btn06.setVisibility(GONE);
		  btn07.setVisibility(GONE);
		  btn08.setVisibility(GONE);
		  show = true;
		  final String sc = wv.getUrl();
		  @SuppressLint("HandlerLeak") final Handler handler = new Handler(){
			@Override
			public void handleMessage(@NonNull Message msg)
			{
			  super.handleMessage(msg);
			  String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
			  wv.loadUrl(shuc);
			}};
		  new Thread(new Runnable(){
			  @Override
			  public void run()
			  {
				try
				{
					String lanApi = "https://xiaobeiit.cn/lanzou/?url=";
					String ipsc = sc;
					if (!ipsc.contains("lanzous.com")) {
						ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
						if (manager != null && manager.hasPrimaryClip()) {
							ClipData data = manager.getPrimaryClip();
							if (data != null) {
								CharSequence addedText = data.getItemAt(0).getText();
								ipsc = String.valueOf(addedText);
							}
						}
					}
					ipsc = ipsc.substring(ipsc.lastIndexOf("/")+1);
					URL url=new URL(lanApi + URLEncoder.encode(ipsc, "UTF-8"));
					conn01 = (HttpURLConnection)url.openConnection();
					conn01.setConnectTimeout(5000);
					if (conn01.getResponseCode() == 200)
					{
						InputStream ipSt01 = conn01.getInputStream();
						BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
						String result01 = br01.readLine();
						JSONObject json01 = new JSONObject(result01);
						br01.close();
						ipSt01.close();
						conn01.disconnect();
						JSONObject textObject = json01.getJSONObject("text");
						String nameStr = textObject.getString("name");
						nameStr = nameStr.substring(0, nameStr.lastIndexOf("."));
						JSONObject downObject = json01.getJSONObject("down");
						String lanDw = downObject.getString("url_dom");
						ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
						ClipData mClipData = ClipData.newPlainText("Label", nameStr);
						if (cm != null) {
							cm.setPrimaryClip(mClipData);
						}
						Bundle bd = new Bundle();
						bd.putString("content", lanDw);
						Message message = new Message();
						message.setData(bd);
						handler.sendMessage(message);
					}
				  else
				  {
					conn01.disconnect();
				  }} catch (Exception e)
				  {
					e.printStackTrace();
				  }
			  }}).start();
		}});

	btn04.setOnClickListener(new View.OnClickListener() {
		@Override
		public void onClick(View v)
		{
		  btn02.setVisibility(GONE);
		  btn03.setVisibility(GONE);
		  btn04.setVisibility(GONE);
		  btn05.setVisibility(GONE);
		  btn06.setVisibility(GONE);
		  btn07.setVisibility(GONE);
		  btn08.setVisibility(GONE);
		  show = true;
		  final String sc = wv.getUrl();
		  new Thread(new Runnable(){
			  @Override
			  public void run()
			  {
				try
				{
				  String suoApi = "https://xiaobeiit.cn/api/ys.php?url=";
				  URL url=new URL(suoApi + URLEncoder.encode(sc, "UTF-8"));
				  conn01 = (HttpURLConnection)url.openConnection();
				  conn01.setConnectTimeout(5000);
				  if (conn01.getResponseCode() == 200)
				  {
					InputStream ipSt01 = conn01.getInputStream();
					BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
					String suoDw = br01.readLine();
					br01.close();
					ipSt01.close();
					conn01.disconnect();
					ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
					ClipData mClipData = ClipData.newPlainText("Label", suoDw);
					  if (cm != null) {
						  cm.setPrimaryClip(mClipData);
					  }
				  }
				  else
				  {
					conn01.disconnect();
				  }}
				catch (Exception e)
				{
				  e.printStackTrace();
				}
			  }}).start();
		}});

	btn05.setOnClickListener(new View.OnClickListener() {
		@Override
		public void onClick(View v)
		{
		  btn02.setVisibility(GONE);
		  btn03.setVisibility(GONE);
		  btn04.setVisibility(GONE);
		  btn05.setVisibility(GONE);
		  btn06.setVisibility(GONE);
		  btn07.setVisibility(GONE);
		  btn08.setVisibility(GONE);
		  show = true;
		  if (zhuom)
		  {
			wv.getSettings().setUserAgentString("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36");
			wv.getSettings().setBuiltInZoomControls(true);
			zhuom = false;
		  }
		  else
		  {
			wv.getSettings().setUserAgentString(azua);
			wv.getSettings().setBuiltInZoomControls(false);
			zhuom = true;
		  }
		  wv.reload();
		}});

	btn05.setOnLongClickListener(new View.OnLongClickListener(){
		@Override
		public boolean onLongClick(View v)
		{
		  btn02.setVisibility(GONE);
		  btn03.setVisibility(GONE);
		  btn04.setVisibility(GONE);
		  btn05.setVisibility(GONE);
		  btn06.setVisibility(GONE);
		  btn07.setVisibility(GONE);
		  btn08.setVisibility(GONE);
		  show = true;
		  wv.getSettings().setUserAgentString(azua);
		  wv.getSettings().setBuiltInZoomControls(false);
		  wv.reload();
		  return true;
		}
	  });

	btn06.setOnClickListener(new View.OnClickListener() {
		@Override
		public void onClick(View v)
		{
		  btn02.setVisibility(GONE);
		  btn03.setVisibility(GONE);
		  btn04.setVisibility(GONE);
		  btn05.setVisibility(GONE);
		  btn06.setVisibility(GONE);
		  btn07.setVisibility(GONE);
		  btn08.setVisibility(GONE);
		  show = true;
		  if (wv.canGoBack())
		  {
			wv.goBack();
		  }
		}});

	btn06.setOnLongClickListener(new View.OnLongClickListener(){
		@Override
		public boolean onLongClick(View v)
		{
		  btn02.setVisibility(GONE);
		  btn03.setVisibility(GONE);
		  btn04.setVisibility(GONE);
		  btn05.setVisibility(GONE);
		  btn06.setVisibility(GONE);
		  btn07.setVisibility(GONE);
		  btn08.setVisibility(GONE);
		  show = true;
		  wv.scrollTo(0, 0);
		  return true;
		}
	  });

	btn07.setOnClickListener(new View.OnClickListener() {
		@Override
		public void onClick(View v)
		{
		  btn02.setVisibility(GONE);
		  btn03.setVisibility(GONE);
		  btn04.setVisibility(GONE);
		  btn05.setVisibility(GONE);
		  btn06.setVisibility(GONE);
		  btn07.setVisibility(GONE);
		  btn08.setVisibility(GONE);
		  show = true;
		  wv.goForward();
		}});

	btn07.setOnLongClickListener(new View.OnLongClickListener(){
		@Override
		public boolean onLongClick(View v)
		{
		  wv.scrollBy(0, wv.getHeight() - 10);
		  return true;
		}
	  });

	btn08.setOnClickListener(new View.OnClickListener() {
		@Override
		public void onClick(View v)
		{
		  btn02.setVisibility(GONE);
		  btn03.setVisibility(GONE);
		  btn04.setVisibility(GONE);
		  btn05.setVisibility(GONE);
		  btn06.setVisibility(GONE);
		  btn07.setVisibility(GONE);
		  btn08.setVisibility(GONE);
		  show = true;
		  wv.reload();
		}});

	btn08.setOnLongClickListener(new View.OnLongClickListener(){
		@Override
		public boolean onLongClick(View v)
		{
		  if (erji)
		  {
			btn02.setVisibility(GONE);
			btn03.setVisibility(GONE);
			btn04.setVisibility(GONE);
			btn09.setVisibility(VISIBLE);
			btn10.setVisibility(VISIBLE);
			btn11.setVisibility(VISIBLE);
			erji = false;
		  }
		  else
		  {
			btn02.setVisibility(VISIBLE);
			btn03.setVisibility(VISIBLE);
			btn04.setVisibility(VISIBLE);
			btn09.setVisibility(GONE);
			btn10.setVisibility(GONE);
			btn11.setVisibility(GONE);
			erji = true;
		  }
		  return true;
		}
	  });

	btn09.setOnClickListener(new View.OnClickListener() {
		@Override
		public void onClick(View v)
		{
		  btn05.setVisibility(GONE);
		  btn06.setVisibility(GONE);
		  btn07.setVisibility(GONE);
		  btn08.setVisibility(GONE);
		  btn09.setVisibility(GONE);
		  btn10.setVisibility(GONE);
		  btn11.setVisibility(GONE);
		  show = true;
		  ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
		  ClipData mClipData = ClipData.newPlainText("Label", wv.getUrl());
			if (cm != null) {
				cm.setPrimaryClip(mClipData);
			}
			wv.getSettings().setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.92 Safari/537.36");
		  wv.loadUrl("https://jsap.attakids.com/?url=" + wv.getUrl());
		}});

	btn10.setOnClickListener(new View.OnClickListener() {
		@Override
		public void onClick(View v)
		{
		  btn05.setVisibility(GONE);
		  btn06.setVisibility(GONE);
		  btn07.setVisibility(GONE);
		  btn08.setVisibility(GONE);
		  btn09.setVisibility(GONE);
		  btn10.setVisibility(GONE);
		  btn11.setVisibility(GONE);
		  show = true;
		  ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
		  ClipData mClipData = ClipData.newPlainText("Label", wv.getUrl());
			if (cm != null) {
				cm.setPrimaryClip(mClipData);
			}
			wv.getSettings().setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.92 Safari/537.36");
		  wv.loadUrl("https://vip.52jiexi.top/?url=" + wv.getUrl());
		}});

	btn11.setOnClickListener(new View.OnClickListener() {
		@Override
		public void onClick(View v)
		{
		  btn05.setVisibility(GONE);
		  btn06.setVisibility(GONE);
		  btn07.setVisibility(GONE);
		  btn08.setVisibility(GONE);
		  btn09.setVisibility(GONE);
		  btn10.setVisibility(GONE);
		  btn11.setVisibility(GONE);
		  show = true;
		  ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
		  ClipData mClipData = ClipData.newPlainText("Label", wv.getUrl());
			if (cm != null) {
				cm.setPrimaryClip(mClipData);
			}
			wv.getSettings().setUserAgentString(azua);
		  wv.loadUrl("https://jx.elwtc.com/vip/?url=" + wv.getUrl());
		}});

	if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
	{
	  wv.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
	}
	if (Intent.ACTION_SEND.equals(action) && type != null)
	{
	  if ("text/plain".equals(type))
	  {
		handleSendText(intent);
	  } }

	wv.setLayerType(View.LAYER_TYPE_HARDWARE, null);
	wv.setHorizontalScrollBarEnabled(false);
	wv.setVerticalScrollBarEnabled(false);
	wv.getSettings().setBuiltInZoomControls(false);
	wv.getSettings().setDisplayZoomControls(false);
	wv.getSettings().setDomStorageEnabled(true);
	wv.getSettings().setUseWideViewPort(true);
	wv.getSettings().setJavaScriptEnabled(true);
	wv.getSettings().setLoadWithOverviewMode(true);	
	wv.getSettings().setSupportZoom(true);
	wv.setBackgroundColor(0);
	wv.getBackground().setAlpha(2);
	CookieSyncManager.createInstance(this);
	CookieManager cookieManager = CookieManager.getInstance();
	cookieManager.setAcceptCookie(true);
	  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
		  CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true);
	  }
	  wv.getSettings().setUserAgentString(wv.getSettings().getUserAgentString());
	wv.setWebChromeClient(new WebChromeClient(){
		private CustomViewCallback mCallBack;
		@Override
		public boolean onJsAlert(WebView view, String url, String message, JsResult result)
		{
		  Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
		  result.confirm();
		  return true;
		}
		@Override
		public void onShowCustomView(View view, CustomViewCallback callback)
		{
		  getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		  getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		  fullScreen();
		  btn01.setVisibility(GONE);
		  wv.setVisibility(GONE);
		  vc.setVisibility(VISIBLE);
		  vc.addView(view);
		  mCallBack = callback;
		  super.onShowCustomView(view, callback);
		}
		@Override
		public void onHideCustomView()
		{
		  getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		  getWindow().setFlags(0, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		  fullScreen();
		  if (mCallBack != null)
		  {
			mCallBack.onCustomViewHidden();
		  }
		  wv.setVisibility(VISIBLE);
		  btn01.setVisibility(VISIBLE);
		  vc.setVisibility(GONE);
		  vc.removeAllViews();
		  super.onHideCustomView();
		}
		@SuppressLint("SourceLockedOrientationActivity")
		private void fullScreen()
		{
		  if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT)
		  {
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		  }
		  else
		  {
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		  }}
	  });
	wv.setWebViewClient(new WebViewClient(){
		@Override
		public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request)
		{
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
				if (request.getUrl().toString().contains("woozoo") || request.getUrl().toString().contains("cnzz") || request.getUrl().toString().contains("googlesyndication"))
				{
				  return new WebResourceResponse(null, null, null);
				}
				else
				{
				  return super.shouldInterceptRequest(view, request);
				}
			}
			return null;
		}
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url)
		{
		  if (url.startsWith("imgotv") || url.startsWith("hntv") || url.startsWith("baidu"))
		  {
			return true;
		  }
		  if (shouldOverrideUrlLoadingByApp(url))
		  {
			Toast.makeText(WebActivity.this, "Jump to external app", Toast.LENGTH_SHORT).show();
			return true;
		  }
		  return super.shouldOverrideUrlLoading(view, url);
		} 
	  });
	wv.setDownloadListener(new DownloadListener() {
		@Override
		public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength)
		{
		  Intent i = new Intent(Intent.ACTION_VIEW);
		  i.setData(Uri.parse(url));
		  startActivity(i);
		}});
  }
  @Override
  protected void onNewIntent(Intent intent)
  {
	super.onNewIntent(intent);
	getDataFromBrowser(intent);
  }
  private void getDataFromBrowser(Intent intent)
  {
	Uri data = intent.getData();
	if (data != null)
	{
	  try
	  {
		String scheme = data.getScheme();
		String host = data.getHost();
		String path = data.getPath();
		String url = scheme + "://" + host + path;
		wv.loadUrl(url);
	  }
	  catch (Exception e)
	  {
		e.printStackTrace();
	  }}}
  private void handleSendText(Intent intent)
  {
	String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
	if (sharedText != null)
	{
	  try
	  {
		wv.loadUrl(sharedText);
	  }
	  catch (Exception e)
	  {
		e.printStackTrace();
	  }}}
  @Override
  public boolean onKeyDown(int keyCode, KeyEvent event)
  {
	if (keyCode == KeyEvent.KEYCODE_BACK && wv.canGoBack())
	{
	  wv.goBack();
	  return true;
	}
	return super.onKeyDown(keyCode, event);
  }
  @Override
  protected void onDestroy()
  {
	if (wv != null)
	{
	  wv.loadDataWithBaseURL(null, "", "text/html", "utf-8", null);
	  wv.clearHistory();
	  ((ViewGroup) wv.getParent()).removeView(wv);
	  wv.destroy();
	  wv = null;
	}
	super.onDestroy();
  }
  private void getData()
  {
	webViewUrl = getIntent().getStringExtra("webview_url");
  }
  private void initViews()
  {
	wv.loadUrl(webViewUrl);
  }
  private void loadData()
  {
	wv.loadUrl(webViewUrl);
  }
  private boolean shouldOverrideUrlLoadingByApp(String url)
  {
	if (url.startsWith("http") || url.startsWith("https") || url.startsWith("ftp"))
	{
	  return false;
	}
	Intent intent;
	try
	{
	  intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
	}
	catch (URISyntaxException e)
	{
	  return false;
	}
	intent.setComponent(null);
	try
	{
	  WebActivity.this.startActivity(intent);
	}
	catch (ActivityNotFoundException e)
	{
	  return false;
	}
	return true;
  }
  public static void skip(Activity MainActivity, String webviewUrl)
  {
	Intent intent = new Intent(MainActivity, WebActivity.class);
	intent.putExtra("webview_url", webviewUrl);
	MainActivity.startActivity(intent);
  }
  private void mvUrl()
  {
	  String jxUrl = getIntent().getStringExtra("jx");
	wv.loadUrl(jxUrl);}
}
