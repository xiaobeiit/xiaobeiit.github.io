package com.huidu.app;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class PureSc extends Activity
{
	@Override
    protected void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
		getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
		int option = getWindow().getDecorView().getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
        getWindow().getDecorView().setSystemUiVisibility(option);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
		setContentView(R.layout.puresc);
		final EditText ed01 = findViewById(R.id.ed01);
		Button btn01 = findViewById(R.id.btn01);
	    Button btn02 = findViewById(R.id.btn02);
	    Button btn03 = findViewById(R.id.btn03);

		btn01.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					String sc = ed01.getText().toString();
					String scone = "https://www.google.com.hk/search?safe=strict&q=" + sc;
					Intent intent = new Intent(PureSc.this, WebActivity.class);
					intent.putExtra("jx", scone);
					startActivity(intent);}});

		btn02.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					String sc = ed01.getText().toString();
					String sctwo = "https://www.baidu.com/s?wd=" + sc;
					Intent intent = new Intent(PureSc.this, WebActivity.class);
					intent.putExtra("jx", sctwo);
					startActivity(intent);}});

		btn03.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					String sc = ed01.getText().toString();
					if (sc.length() != 0)
					{
						if (sc.indexOf("http") != -1)
						{
							Intent intent = new Intent(PureSc.this, WebActivity.class);
							intent.putExtra("jx", sc);
							startActivity(intent);
						}
						else
						{
							sc = "https://" + sc;
							Intent intent = new Intent(PureSc.this, WebActivity.class);
							intent.putExtra("jx", sc);
							startActivity(intent);
						}}
					else
					{
						ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
						CharSequence addedText = manager.getPrimaryClip().getItemAt(0).getText();
						String scurl = String.valueOf(addedText);
						if (scurl.indexOf("http") != -1)
						{
							Intent intent = new Intent(PureSc.this, WebActivity.class);
							intent.putExtra("jx", scurl);
							startActivity(intent);
						}
						else
						{
							scurl = "https://" + scurl;
							Intent intent = new Intent(PureSc.this, WebActivity.class);
							intent.putExtra("jx", scurl);
							startActivity(intent);
						}
					}
				}});
	}}
