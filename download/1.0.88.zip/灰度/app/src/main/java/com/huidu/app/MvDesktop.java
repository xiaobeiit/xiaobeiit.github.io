package com.huidu.app;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.content.res.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;

public class MvDesktop extends Activity
{
	private WebView wv;
	private FrameLayout vc;
	private String jxUrl;
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		int option = getWindow().getDecorView().getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
        getWindow().getDecorView().setSystemUiVisibility(option);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
		setContentView(R.layout.browser);
        wv = findViewById(R.id.webView);
        vc = findViewById(R.id.videoContainer);
		mvUrl();
		getDataFromBrowser(getIntent());
		handleSendText(getIntent());
		Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
		{
            wv.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
		}
		if (Intent.ACTION_SEND.equals(action) && type != null)
		{
            if ("text/plain".equals(type))
			{
                handleSendText(intent);
            } }
		wv.setLayerType(View.LAYER_TYPE_HARDWARE, null);
		wv.setHorizontalScrollBarEnabled(false);
		wv.setVerticalScrollBarEnabled(false);
		wv.getSettings().setBuiltInZoomControls(false);
		wv.getSettings().setUseWideViewPort(true);
		wv.getSettings().setJavaScriptEnabled(true);
		wv.getSettings().setLoadWithOverviewMode(true);	
		wv.getSettings().setSupportZoom(true);
		wv.getSettings().setDomStorageEnabled(true);
		wv.getSettings().setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.92 Safari/537.36");
		wv.setBackgroundColor(0);
		wv.getBackground().setAlpha(2);
		CookieSyncManager.createInstance(this);
		CookieManager cookieManager = CookieManager.getInstance();
		cookieManager.setAcceptCookie(true);
		CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true);
		wv.getSettings().setUserAgentString(wv.getSettings().getUserAgentString());
		wv.setWebChromeClient(new WebChromeClient(){
				private WebChromeClient.CustomViewCallback mCallBack;
				@Override
				public void onShowCustomView(View view, CustomViewCallback callback)
				{
					fullScreen();
					wv.setVisibility(View.GONE);
					vc.setVisibility(View.VISIBLE);
					vc.addView(view);
					mCallBack = callback;
					super.onShowCustomView(view, callback);
				}
				@Override
				public void onHideCustomView()
				{
					fullScreen();
					if (mCallBack != null)
					{
						mCallBack.onCustomViewHidden();
					}
					wv.setVisibility(View.VISIBLE);
					vc.setVisibility(View.GONE);
					vc.removeAllViews();
					super.onHideCustomView();
				}
				private void fullScreen()
				{
					if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT)
					{
						setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
					}
					else
					{
						setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
					}}
			});
		wv.setWebViewClient(new WebViewClient(){
				@Override
				public boolean shouldOverrideUrlLoading(WebView view, String url)
				{
					return false;
                } 
			});
		wv.setDownloadListener(new DownloadListener() {
				@Override
				public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength)
				{
					Intent i = new Intent(Intent.ACTION_VIEW);
					i.setData(Uri.parse(url));
					startActivity(i);
				}});
	}
	@Override
    protected void onNewIntent(Intent intent)
	{
        super.onNewIntent(intent);
        getDataFromBrowser(intent);
    }
    private void getDataFromBrowser(Intent intent)
	{
        Uri data = intent.getData();
        if (data != null)
		{
            try
			{
                String scheme = data.getScheme();
                String host = data.getHost();
                String path = data.getPath();
                String url = "http://jsap.attakids.com/?url=" + scheme + "://" + host + path;
                wv.loadUrl(url);
            }
			catch (Exception e)
			{
                e.printStackTrace();
            }}}
	private void handleSendText(Intent intent)
	{
        String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (sharedText != null)
		{
			try
			{
				String url = "http://jsap.attakids.com/?url=" + sharedText;
				wv.loadUrl(url);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}}}
	@Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
	{
        if (keyCode == KeyEvent.KEYCODE_BACK && wv.canGoBack())
		{
            wv.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    @Override
    protected void onDestroy()
	{
        if (wv != null)
		{
            wv.loadDataWithBaseURL(null, "", "text/html", "utf-8", null);
            wv.clearHistory();
            ((ViewGroup) wv.getParent()).removeView(wv);
            wv.destroy();
            wv = null;
        }
        super.onDestroy();
    }
    private void mvUrl()
	{
        jxUrl = getIntent().getStringExtra("jx");
		wv.loadUrl(jxUrl);}
}
