package com.huidu.app;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity
{
	@Override
    protected void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
		getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
		int option = getWindow().getDecorView().getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
        getWindow().getDecorView().setSystemUiVisibility(option);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
		setContentView(R.layout.main);

		Button btn01 = findViewById(R.id.btn01);
		Button btn02 = findViewById(R.id.btn02);
		Button btn03 = findViewById(R.id.btn03);
		Button btn04 = findViewById(R.id.btn04);
		Button btn05 = findViewById(R.id.btn05);
		Button btn06 = findViewById(R.id.btn06);
		Button btn07 = findViewById(R.id.btn07);
		Button btn08 = findViewById(R.id.btn08);
		Button btn09 = findViewById(R.id.btn09);

        btn01.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					Intent intent = new Intent(MainActivity.this, MvSearch.class);
					startActivity(intent);
				}});

		btn02.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					Intent intent = new Intent(MainActivity.this, PureSc.class);
					startActivity(intent);
				}});

        btn03.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					Intent intent = new Intent(MainActivity.this, HuiduActivity.class);
					startActivity(intent);
				}});

        btn04.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
                    WebActivity.skip(MainActivity.this, "https://xiaobeiit.gitee.io/huidu/lingzanba.html");
				}});

        btn05.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
                    WebActivity.skip(MainActivity.this, "https://xiaobeiit.gitee.io/soft.html");
				}});

        btn06.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
                    WebActivity.skip(MainActivity.this, "https://xiaobeiit.gitee.io/fzs.html");
				}});

        btn07.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
                    WebActivity.skip(MainActivity.this, "https://xiaobeiit.gitee.io/huidu/liulanba.html");
				}});

        btn08.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
                    WebActivity.skip(MainActivity.this, "https://xiaobeiit.gitee.io/huidu/shuoshuoba.html");
				}});

        btn09.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
                    WebActivity.skip(MainActivity.this, "https://xiaobeiit.gitee.io/shisuiji.html");
				}});
	}}