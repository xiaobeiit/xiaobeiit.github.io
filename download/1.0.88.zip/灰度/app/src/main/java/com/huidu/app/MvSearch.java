package com.huidu.app;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class MvSearch extends Activity
{
	@Override
    protected void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
		getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
		int option = getWindow().getDecorView().getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
        getWindow().getDecorView().setSystemUiVisibility(option);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
		setContentView(R.layout.mvsearch);
		final EditText ed01 = findViewById(R.id.ed01);
		Button btn01 = findViewById(R.id.btn01);
	    Button btn02 = findViewById(R.id.btn02);
	    Button btn03 = findViewById(R.id.btn03);
	    Button btn04 = findViewById(R.id.btn04);
	    Button btn05 = findViewById(R.id.btn05);
	    Button btn06 = findViewById(R.id.btn06);
	    Button btn07 = findViewById(R.id.btn07);
	    Button btn08 = findViewById(R.id.btn08);

		btn01.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					String sc = ed01.getText().toString();
					String scone = "https://m.iqiyi.com/search.html?key=" + sc;
					Intent intent = new Intent(MvSearch.this, MvWeb.class);
					intent.putExtra("search", scone);
					startActivity(intent);}});

		btn02.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					String sc = ed01.getText().toString();
					String sctwo = "http://m.v.qq.com/search.html?keyWord=" + sc;
					Intent intent = new Intent(MvSearch.this, MvWeb.class);
					intent.putExtra("search", sctwo);
					startActivity(intent);}});

		btn03.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					String sc = ed01.getText().toString();
					String scthree = "https://search.youku.com/search_video?keyword=" + sc;
					Intent intent = new Intent(MvSearch.this, MvWeb.class);
					intent.putExtra("search", scthree);
					startActivity(intent);}});

		btn04.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					String sc = ed01.getText().toString();
					String scfour = "https://m.mgtv.com/so/?k=" + sc;
					Intent intent = new Intent(MvSearch.this, MvWeb.class);
					intent.putExtra("search", scfour);
					startActivity(intent);}});

		btn05.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					String sc = ed01.getText().toString();
					if (sc.length() != 0)
					{
						String jxone = "http://jsap.attakids.com/?url=" + sc;
						Intent intent = new Intent(MvSearch.this, MvDesktop.class);
						intent.putExtra("jx", jxone);
						startActivity(intent);
					}
					else
					{
						ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
						CharSequence addedText = manager.getPrimaryClip().getItemAt(0).getText();
						String scurl = String.valueOf(addedText);
						String jxone = "http://jsap.attakids.com/?url=" + scurl;
						Intent intent = new Intent(MvSearch.this, MvDesktop.class);
						intent.putExtra("jx", jxone);
						startActivity(intent);}}});

		btn06.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					String sc = ed01.getText().toString();
					if (sc.length() != 0)
					{
						String jxtwo = "http://www.ckmov.com/?url=" + sc;
						Intent intent = new Intent(MvSearch.this, MvDesktop.class);
						intent.putExtra("jx", jxtwo);
						startActivity(intent);
					}
					else
					{
						ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
						CharSequence addedText = manager.getPrimaryClip().getItemAt(0).getText();
						String scurl = String.valueOf(addedText);
						String jxtwo = "http://www.ckmov.com/?url=" + scurl;
						Intent intent = new Intent(MvSearch.this, MvDesktop.class);
						intent.putExtra("jx", jxtwo);
						startActivity(intent);}}});

		btn07.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					String sc = ed01.getText().toString();
					if (sc.length() != 0)
					{
						String jxthree = "https://z1.m1907.cn/?jx=" + sc;
						Intent intent = new Intent(MvSearch.this, WebActivity.class);
						intent.putExtra("jx", jxthree);
						startActivity(intent);
					}
					else
					{
						ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
						CharSequence addedText = manager.getPrimaryClip().getItemAt(0).getText();
						String scurl = String.valueOf(addedText);
						String jxthree = "https://z1.m1907.cn/?jx=" + scurl;
						Intent intent = new Intent(MvSearch.this, WebActivity.class);
						intent.putExtra("jx", jxthree);
						startActivity(intent);}}});

		btn08.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					String sc = ed01.getText().toString();
					if (sc.length() != 0)
					{
						if (sc.indexOf("http") != -1)
						{
							Intent intent = new Intent(MvSearch.this, MvWeb.class);
							intent.putExtra("search", sc);
							startActivity(intent);
						}
						else
						{
							sc = "https://" + sc;
							Intent intent = new Intent(MvSearch.this, MvWeb.class);
							intent.putExtra("search", sc);
							startActivity(intent);
						}}
					else
					{
						ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
						CharSequence addedText = manager.getPrimaryClip().getItemAt(0).getText();
						String scurl = String.valueOf(addedText);
						if (scurl.indexOf("http") != -1)
						{
							Intent intent = new Intent(MvSearch.this, MvWeb.class);
							intent.putExtra("search", scurl);
							startActivity(intent);
						}
						else
						{
							scurl = "https://" + scurl;
							Intent intent = new Intent(MvSearch.this, MvWeb.class);
							intent.putExtra("search", scurl);
							startActivity(intent);
						}
					}
				}});
	}}
