package com.huidu.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class MainActivity extends Activity {
    private HttpURLConnection conn01, conn02;
    private boolean huidu = true;
    private boolean fanyi = true;
    private boolean movie = true;
    private String sc;
    private String failed = "这位同学，该请求闭关修炼中、或已圆寂";
    private String jsonError = "这位同学，处理返回数据出错";
    private String endStr;
    private String scjump;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        int option = getWindow().getDecorView().getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
        getWindow().getDecorView().setSystemUiVisibility(option);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
        }
        setContentView(R.layout.main);

        final EditText ed01 = findViewById(R.id.ed01);
        final TextView tv01 = findViewById(R.id.tv01);
        final Button btn01 = findViewById(R.id.btn01);
        final Button btn02 = findViewById(R.id.btn02);
        final Button btn03 = findViewById(R.id.btn03);
        final Button btn04 = findViewById(R.id.btn04);
        final Button btn05 = findViewById(R.id.btn05);
        final Button btn06 = findViewById(R.id.btn06);
        final Button btn07 = findViewById(R.id.btn07);
        final Button btn08 = findViewById(R.id.btn08);
        final Button btn09 = findViewById(R.id.btn09);
        final Button btn10 = findViewById(R.id.btn10);
        final Button btn11 = findViewById(R.id.btn11);
        final Button btn12 = findViewById(R.id.btn12);
        final Button btn13 = findViewById(R.id.btn13);
        final Button btn14 = findViewById(R.id.btn14);
        final Button btn15 = findViewById(R.id.btn15);
        final Button btn16 = findViewById(R.id.btn16);
        final Button btn17 = findViewById(R.id.btn17);
        final Button btn18 = findViewById(R.id.btn18);
        final Button btn19 = findViewById(R.id.btn19);
        final Button btn20 = findViewById(R.id.btn20);
        final Button btn21 = findViewById(R.id.btn21);
        final Button btn22 = findViewById(R.id.btn22);
        final Button btn23 = findViewById(R.id.btn23);
        final Button btn24 = findViewById(R.id.btn24);
        final Button btn25 = findViewById(R.id.btn25);
        final Button btn26 = findViewById(R.id.btn26);
        final Button btn27 = findViewById(R.id.btn27);
        final Button btn28 = findViewById(R.id.btn28);
        final Button btn29 = findViewById(R.id.btn29);
        final Button btn30 = findViewById(R.id.btn30);
        final Button btn31 = findViewById(R.id.btn31);
        final Button btn32 = findViewById(R.id.btn32);
        final TableRow table01 = findViewById(R.id.table01);
        final TableRow table02 = findViewById(R.id.table02);
        final TableRow table03 = findViewById(R.id.table03);
        final TableRow table04 = findViewById(R.id.table04);
        final TableRow table05 = findViewById(R.id.table05);
        final TableRow table06 = findViewById(R.id.table06);
        final TableRow table07 = findViewById(R.id.table07);

        Intent i = new Intent(MainActivity.this, WebActivity.class);

        tv01.setOnClickListener(v -> {
            copyString(tv01.getText().toString());
            tv01.setText("");
        });

        ed01.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                editTextHide(ed01);
                @SuppressLint("HandlerLeak") final Handler handler = new Handler() {
                    @Override
                    public void handleMessage(@NonNull Message msg) {
                        super.handleMessage(msg);
                        String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
                        tv01.setText(shuc);
                        ed01.setText("");
                    }
                };
                sc = ed01.getText().toString();
                if (sc.length() <= 0) {
                    pasteFromClip();
                }
                Bundle bd = new Bundle();
                bd.putString("content", sc);
                Message message = new Message();
                message.setData(bd);
                handler.sendMessage(message);
                if (!sc.contains("http")) {
                    if (sc.contains(".com") || sc.contains(".cn") || sc.contains(".edu") || sc.contains("cc") || sc.contains(".top") || sc.contains(".io") || sc.contains(".xyz") || sc.contains(".org") || sc.contains(".net")) {
                        sc = "https://" + sc;
                    } else {
                        sc = "https://m.baidu.com/s?from=1022560v&word=" + sc;
                    }
                }
                i.putExtra("jx", sc);
                startActivity(i);
                return false;
            }
        });

        btn01.setOnClickListener(v -> {
            if (huidu) {
                if (table01.getVisibility() == VISIBLE) {
                    table01.setVisibility(GONE);
                    table02.setVisibility(GONE);
                }
                if (table05.getVisibility() == VISIBLE) {
                    table05.setVisibility(GONE);
                    table06.setVisibility(GONE);
                    fanyi = true;
                }
                if (table07.getVisibility() == VISIBLE) {
                    table02.setVisibility(GONE);
                    table07.setVisibility(GONE);
                    movie = true;
                }
                table03.setVisibility(VISIBLE);
                table04.setVisibility(VISIBLE);
            } else {
                if (table05.getVisibility() == VISIBLE) {
                    table05.setVisibility(GONE);
                    table06.setVisibility(GONE);
                    fanyi = true;
                }
                if (table07.getVisibility() == VISIBLE) {
                    table02.setVisibility(GONE);
                    table07.setVisibility(GONE);
                    movie = true;
                }
                table03.setVisibility(GONE);
                table04.setVisibility(GONE);
                table01.setVisibility(VISIBLE);
                table02.setVisibility(VISIBLE);
            }
            huidu = !huidu;
        });

        btn02.setOnClickListener(v -> {
            if (fanyi) {
                if (table01.getVisibility() == VISIBLE) {
                    table01.setVisibility(GONE);
                    table02.setVisibility(GONE);
                }
                if (table03.getVisibility() == VISIBLE) {
                    table03.setVisibility(GONE);
                    table04.setVisibility(GONE);
                    huidu = true;
                }
                if (table07.getVisibility() == VISIBLE) {
                    table02.setVisibility(GONE);
                    table07.setVisibility(GONE);
                    movie = true;
                }
                table05.setVisibility(VISIBLE);
                table06.setVisibility(VISIBLE);
            } else {
                if (table03.getVisibility() == VISIBLE) {
                    table03.setVisibility(GONE);
                    table04.setVisibility(GONE);
                    huidu = true;
                }
                if (table07.getVisibility() == VISIBLE) {
                    table02.setVisibility(GONE);
                    table07.setVisibility(GONE);
                    movie = true;
                }
                table05.setVisibility(GONE);
                table06.setVisibility(GONE);
                table01.setVisibility(VISIBLE);
                table02.setVisibility(VISIBLE);
            }
            fanyi = !fanyi;
        });

        btn03.setOnClickListener(v -> {
            pasteFromClip();
            ed01.setText(sc);
            ed01.setSelection(sc.length());
        });

        btn04.setOnClickListener(v -> {
            tv01.setText("");
            ed01.setText("");
        });

        btn05.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextHide(ed01);
                @SuppressLint("HandlerLeak") final Handler handler = new Handler() {
                    @Override
                    public void handleMessage(@NonNull Message msg) {
                        super.handleMessage(msg);
                        String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
                        tv01.setText(shuc);
                        ed01.setText("");
                    }
                };
                sc = ed01.getText().toString();
                if (sc.length() <= 0) {
                    pasteFromClip();
                }
                String endUrl = "https://quark.sm.cn/api/rest?method=sc.operation_sorting_category&app_chain_name=waste_classify&q=" + Uri.encode(sc, "-![.:/,%?&=]");

                getAsync(endUrl, new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        Bundle bd = new Bundle();
                        bd.putString("content", failed);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                    }

                    @Override
                    public void onResponse(@Nullable Call call, @Nullable Response response) throws IOException {
                        assert response != null;
                        String result01 = Objects.requireNonNull(response.body()).string();
                        JSONObject json01;
                        try {
                            json01 = new JSONObject(result01);
                            String typeStr = json01.getJSONObject("data").getString("waste_type");
                            endStr = typeStr + "\n" + "\n" + sc;
                        } catch (JSONException e) {
                            endStr = jsonError + "\n" + "\n" + sc;
                        }
                        Bundle bd = new Bundle();
                        bd.putString("content", endStr);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                    }
                });
            }
        });

        btn06.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextHide(ed01);
                @SuppressLint("HandlerLeak") final Handler handler = new Handler() {
                    @Override
                    public void handleMessage(@NonNull Message msg) {
                        super.handleMessage(msg);
                        String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
                        tv01.setText(shuc);
                        ed01.setText("");
                    }
                };
                sc = ed01.getText().toString();
                if (sc.length() <= 0) {
                    pasteFromClip();
                } else {
                    copyString(sc);
                }
                String endUrl = "https://api.vvhan.com/api/kuaidi?hao=" + Uri.encode(sc, "-![.:/,%?&=]");

                getAsync(endUrl, new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        Bundle bd = new Bundle();
                        bd.putString("content", failed);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                    }

                    @Override
                    public void onResponse(@Nullable Call call, @Nullable Response response) throws IOException {
                        assert response != null;
                        String result01 = Objects.requireNonNull(response.body()).string();
                        JSONObject json01;
                        try {
                            json01 = new JSONObject(result01);
                            String gsStr = json01.getString("name");
                            JSONObject infoObject = json01.getJSONArray("info").getJSONObject(0);
                            String conStr = infoObject.getString("context");
                            String timeStr = infoObject.getString("time");
                            endStr = conStr + "\n" + "\n" + timeStr + "\n" + "\n" + gsStr;
                        } catch (JSONException e) {
                            endStr = jsonError + "\n" + "\n" + sc;
                        }
                        Bundle bd = new Bundle();
                        bd.putString("content", endStr);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                    }
                });
            }
        });

        btn07.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextHide(ed01);
                @SuppressLint("HandlerLeak") final Handler handler = new Handler() {
                    @Override
                    public void handleMessage(@NonNull Message msg) {
                        super.handleMessage(msg);
                        String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
                        shuc = shuc + "\n" + "\n" + sc;
                        tv01.setText(shuc);
                        ed01.setText("");
                    }
                };
                sc = ed01.getText().toString();
                if (sc.length() <= 0) {
                    pasteFromClip();
                }
                String endUrl = "https://xiaobeiit.cn/api/ys.php?url=" + Uri.encode(sc, "-![.:/,%?&=]");

                getAsync(endUrl, new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        Bundle bd = new Bundle();
                        bd.putString("content", failed);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                    }

                    @Override
                    public void onResponse(@Nullable Call call, @Nullable Response response) throws IOException {
                        assert response != null;
                        endStr = Objects.requireNonNull(response.body()).string();
                        Bundle bd = new Bundle();
                        bd.putString("content", endStr);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                        copyString(endStr);
                    }
                });
            }
        });

        btn08.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextHide(ed01);
                @SuppressLint("HandlerLeak") final Handler handler = new Handler() {
                    @Override
                    public void handleMessage(@NonNull Message msg) {
                        super.handleMessage(msg);
                        String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
                        tv01.setText(shuc);
                        ed01.setText("");
                    }
                };
                sc = ed01.getText().toString();
                if (sc.length() <= 0) {
                    pasteFromClip();
                }
                String endUrl = "https://xiaobeiit.cn/lanzou/?url=" + Uri.encode(sc.substring(sc.lastIndexOf("/") + 1), "-![.:/,%?&=]");

                getAsync(endUrl, new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        Bundle bd = new Bundle();
                        bd.putString("content", failed);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                    }

                    @Override
                    public void onResponse(@Nullable Call call, @Nullable Response response) throws IOException {
                        assert response != null;
                        String result01 = Objects.requireNonNull(response.body()).string();
                        JSONObject json01;
                        try {
                            json01 = new JSONObject(result01);
                            String nameStr = json01.getJSONObject("text").getString("name");
                            String namecopyStr = nameStr.substring(0, nameStr.lastIndexOf("."));
                            String sizeStr = json01.getJSONObject("text").getString("size");
                            String timeStr = json01.getJSONObject("text").getString("time");
                            String lanDw = json01.getJSONObject("down").getString("url_dom");
                            if (lanDw.length() > 0) {
                                endStr = sc + "\n" + "\n" + "File Name : " + nameStr + "\n" + "\n" + "Share Time : " + timeStr + "\n" + "\n" + "File Size : " + sizeStr;
                                copyString(namecopyStr);
                                i.putExtra("jx", lanDw);
                                startActivity(i);
                            }
                        } catch (JSONException e) {
                            endStr = jsonError + "\n" + "\n" + sc;
                        }
                        Bundle bd = new Bundle();
                        bd.putString("content", endStr);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                    }
                });
            }
        });

        btn09.setOnClickListener(v -> {
            editTextHide(ed01);
            sc = ed01.getText().toString();
            if (sc.length() <= 0) {
                pasteFromClip();
            } else {
                copyString(sc);
            }
            scjump = "http://tool.liumingye.cn/music/?page=audioPage&type=migu&name=" + sc;
            tv01.setText(sc);
            ed01.setText("");
            i.putExtra("jx", scjump);
            startActivity(i);
        });

        btn10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextHide(ed01);
                qieDw();
            }

            private void qieDw() {
                @SuppressLint("HandlerLeak") final Handler handler = new Handler() {
                    @Override
                    public void handleMessage(@NonNull Message msg) {
                        super.handleMessage(msg);
                        String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
                        tv01.setText(shuc);
                        ed01.setText("");
                    }
                };
                new Thread(() -> {
                    try {
                        sc = ed01.getText().toString();
                        String qsApi = "https://api.qq.jsososo.com/search?key=";
                        if (sc.length() <= 0) {
                            pasteFromClip();
                        }
                        URL url = new URL(qsApi + URLEncoder.encode(sc, "UTF-8"));
                        conn01 = (HttpURLConnection) url.openConnection();
                        conn01.setConnectTimeout(5000);
                        if (conn01.getResponseCode() == 200) {
                            InputStream ipSt01 = conn01.getInputStream();
                            BufferedReader br01 = new BufferedReader(new InputStreamReader(ipSt01));
                            String result01 = br01.readLine();
                            JSONObject json01 = new JSONObject(result01);
                            br01.close();
                            ipSt01.close();
                            conn01.disconnect();
                            Bundle bd = new Bundle();
                            bd.putString("content", sc);
                            Message message = new Message();
                            message.setData(bd);
                            handler.sendMessage(message);
                            JSONObject listoneObject = json01.getJSONObject("data").getJSONArray("list").getJSONObject(0);
                            String id = listoneObject.getString("songmid");
                            String mcStr = listoneObject.getString("songname");
                            String qf = "https://api.qq.jsososo.com/song/url?id=" + id + "&type=flac";
                            String gsStr = listoneObject.getJSONArray("singer").getJSONObject(0).getString("name");
                            String endStr = gsStr + "-" + mcStr;
                            copyString(endStr);
                            try {
                                URL ur = new URL(qf);
                                conn02 = (HttpURLConnection) ur.openConnection();
                                conn02.setConnectTimeout(5000);
                                if (conn02.getResponseCode() == 200) {
                                    InputStream ipSt02 = conn02.getInputStream();
                                    BufferedReader br02 = new BufferedReader(new InputStreamReader(ipSt02));
                                    String result02 = br02.readLine();
                                    JSONObject json02 = new JSONObject(result02);
                                    br02.close();
                                    ipSt02.close();
                                    conn02.disconnect();
                                    String qieDw = json02.getString("data");
                                    Intent i = new Intent(MainActivity.this, WebActivity.class);
                                    i.putExtra("jx", qieDw);
                                    startActivity(i);
                                } else {
                                    conn02.disconnect();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        } else {
                            conn01.disconnect();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }).start();
            }
        });

        btn11.setOnClickListener(v -> {
            editTextHide(ed01);
            sc = ed01.getText().toString();
            if (sc.length() <= 0) {
                pasteFromClip();
            } else {
                copyString(sc);
            }
            scjump = "http://tool.liumingye.cn/music/?page=audioPage&type=YQD&name=" + sc;
            tv01.setText(sc);
            ed01.setText("");
            i.putExtra("jx", scjump);
            startActivity(i);
        });

        btn12.setOnClickListener(v -> {
            if (movie) {
                table07.setVisibility(VISIBLE);
                table01.setVisibility(GONE);
            } else {
                table01.setVisibility(VISIBLE);
                table07.setVisibility(GONE);
            }
            movie = !movie;
        });

        btn13.setOnClickListener(v -> {
            editTextHide(ed01);
            i.putExtra("jx", "https://xiaobeiit.gitee.io/softbai.html");
            startActivity(i);
        });

        btn13.setOnLongClickListener(v -> {
            editTextHide(ed01);
            i.putExtra("jx", "https://xiaobeiit.gitee.io/soft.html");
            startActivity(i);
            return true;
        });

        btn14.setOnClickListener(v -> {
            editTextHide(ed01);
            i.putExtra("jx", "https://xiaobeiit.gitee.io/shisuijibai.html");
            startActivity(i);
        });

        btn14.setOnLongClickListener(v -> {
            editTextHide(ed01);
            i.putExtra("jx", "https://xiaobeiit.gitee.io/shisuiji.html");
            startActivity(i);
            return true;
        });

        btn15.setOnClickListener(v -> {
            editTextHide(ed01);
            i.putExtra("jx", "https://bbs.xiaobeiit.com/admin");
            startActivity(i);
        });

        btn16.setOnClickListener(v -> {
            editTextHide(ed01);
            i.putExtra("jx", "https://xiaobeiit.gitee.io/web.html");
            startActivity(i);
        });

        btn16.setOnLongClickListener(v -> {
            editTextHide(ed01);
            i.putExtra("jx", "https://xiaobeiit.gitee.io/");
            startActivity(i);
            return true;
        });

        btn17.setOnClickListener(v -> {
            editTextHide(ed01);
            i.putExtra("jx", "https://xiaobeiit.gitee.io/update.html");
            startActivity(i);
        });

        btn18.setOnClickListener(v -> {
            editTextHide(ed01);
            i.putExtra("jx", "https://xiaobeiit.gitee.io/huidu/android/nnxw.html");
            startActivity(i);
        });

        btn19.setOnClickListener(v -> {
            editTextHide(ed01);
            try {
                joinQQGroup("VglHAPvxiNNFWXO0MrqcTxjdKdQzl0Bb");
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        btn20.setOnClickListener(v -> {
            editTextHide(ed01);
            i.putExtra("jx", "https://xiaobeiit.gitee.io/Reward.png");
            startActivity(i);
        });

        btn21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextHide(ed01);
                @SuppressLint("HandlerLeak") final Handler handler = new Handler() {
                    @Override
                    public void handleMessage(@NonNull Message msg) {
                        super.handleMessage(msg);
                        String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
                        shuc = shuc + "\n" + "\n" + sc;
                        tv01.setText(shuc);
                        ed01.setText("");
                    }
                };
                sc = ed01.getText().toString();
                if (sc.length() <= 0) {
                    pasteFromClip();
                }
                String endUrl = "https://xiaobeiit.cn/api/fy.php?t=zh&w=" + Uri.encode(sc, "-![.:/,%?&=]");

                getAsync(endUrl, new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        Bundle bd = new Bundle();
                        bd.putString("content", failed);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                    }

                    @Override
                    public void onResponse(@Nullable Call call, @Nullable Response response) throws IOException {
                        assert response != null;
                        endStr = Objects.requireNonNull(response.body()).string();
                        Bundle bd = new Bundle();
                        bd.putString("content", endStr);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                        copyString(endStr);
                    }
                });
            }
        });


        btn22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextHide(ed01);
                @SuppressLint("HandlerLeak") final Handler handler = new Handler() {
                    @Override
                    public void handleMessage(@NonNull Message msg) {
                        super.handleMessage(msg);
                        String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
                        shuc = shuc + "\n" + "\n" + sc;
                        tv01.setText(shuc);
                        ed01.setText("");
                    }
                };
                sc = ed01.getText().toString();
                if (sc.length() <= 0) {
                    pasteFromClip();
                }
                String endUrl = "https://xiaobeiit.cn/api/fy.php?t=en&w=" + Uri.encode(sc, "-![.:/,%?&=]");

                getAsync(endUrl, new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        Bundle bd = new Bundle();
                        bd.putString("content", failed);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                    }

                    @Override
                    public void onResponse(@Nullable Call call, @Nullable Response response) throws IOException {
                        assert response != null;
                        endStr = Objects.requireNonNull(response.body()).string();
                        Bundle bd = new Bundle();
                        bd.putString("content", endStr);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                        copyString(endStr);
                    }
                });
            }
        });

        btn23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextHide(ed01);
                @SuppressLint("HandlerLeak") final Handler handler = new Handler() {
                    @Override
                    public void handleMessage(@NonNull Message msg) {
                        super.handleMessage(msg);
                        String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
                        shuc = shuc + "\n" + "\n" + sc;
                        tv01.setText(shuc);
                        ed01.setText("");
                    }
                };
                sc = ed01.getText().toString();
                if (sc.length() <= 0) {
                    pasteFromClip();
                }
                String endUrl = "https://xiaobeiit.cn/api/fy.php?t=jp&w=" + Uri.encode(sc, "-![.:/,%?&=]");

                getAsync(endUrl, new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        Bundle bd = new Bundle();
                        bd.putString("content", failed);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                    }

                    @Override
                    public void onResponse(@Nullable Call call, @Nullable Response response) throws IOException {
                        assert response != null;
                        endStr = Objects.requireNonNull(response.body()).string();
                        Bundle bd = new Bundle();
                        bd.putString("content", endStr);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                        copyString(endStr);
                    }
                });
            }
        });

        btn24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextHide(ed01);
                @SuppressLint("HandlerLeak") final Handler handler = new Handler() {
                    @Override
                    public void handleMessage(@NonNull Message msg) {
                        super.handleMessage(msg);
                        String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
                        shuc = shuc + "\n" + "\n" + sc;
                        tv01.setText(shuc);
                        ed01.setText("");
                    }
                };
                sc = ed01.getText().toString();
                if (sc.length() <= 0) {
                    pasteFromClip();
                }
                String endUrl = "https://xiaobeiit.cn/api/fy.php?t=kor&w=" + Uri.encode(sc, "-![.:/,%?&=]");

                getAsync(endUrl, new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        Bundle bd = new Bundle();
                        bd.putString("content", failed);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                    }

                    @Override
                    public void onResponse(@Nullable Call call, @Nullable Response response) throws IOException {
                        assert response != null;
                        endStr = Objects.requireNonNull(response.body()).string();
                        Bundle bd = new Bundle();
                        bd.putString("content", endStr);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                        copyString(endStr);
                    }
                });
            }
        });

        btn25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextHide(ed01);
                @SuppressLint("HandlerLeak") final Handler handler = new Handler() {
                    @Override
                    public void handleMessage(@NonNull Message msg) {
                        super.handleMessage(msg);
                        String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
                        shuc = shuc + "\n" + "\n" + sc;
                        tv01.setText(shuc);
                        ed01.setText("");
                    }
                };
                sc = ed01.getText().toString();
                if (sc.length() <= 0) {
                    pasteFromClip();
                }
                String endUrl = "https://xiaobeiit.cn/api/fy.php?t=fra&w=" + Uri.encode(sc, "-![.:/,%?&=]");

                getAsync(endUrl, new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        Bundle bd = new Bundle();
                        bd.putString("content", failed);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                    }

                    @Override
                    public void onResponse(@Nullable Call call, @Nullable Response response) throws IOException {
                        assert response != null;
                        endStr = Objects.requireNonNull(response.body()).string();
                        Bundle bd = new Bundle();
                        bd.putString("content", endStr);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                        copyString(endStr);
                    }
                });
            }
        });

        btn26.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextHide(ed01);
                @SuppressLint("HandlerLeak") final Handler handler = new Handler() {
                    @Override
                    public void handleMessage(@NonNull Message msg) {
                        super.handleMessage(msg);
                        String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
                        shuc = shuc + "\n" + "\n" + sc;
                        tv01.setText(shuc);
                        ed01.setText("");
                    }
                };
                sc = ed01.getText().toString();
                if (sc.length() <= 0) {
                    pasteFromClip();
                }
                String endUrl = "https://xiaobeiit.cn/api/fy.php?t=th&w=" + Uri.encode(sc, "-![.:/,%?&=]");

                getAsync(endUrl, new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        Bundle bd = new Bundle();
                        bd.putString("content", failed);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                    }

                    @Override
                    public void onResponse(@Nullable Call call, @Nullable Response response) throws IOException {
                        assert response != null;
                        endStr = Objects.requireNonNull(response.body()).string();
                        Bundle bd = new Bundle();
                        bd.putString("content", endStr);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                        copyString(endStr);
                    }
                });
            }
        });

        btn27.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextHide(ed01);
                @SuppressLint("HandlerLeak") final Handler handler = new Handler() {
                    @Override
                    public void handleMessage(@NonNull Message msg) {
                        super.handleMessage(msg);
                        String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
                        shuc = shuc + "\n" + "\n" + sc;
                        tv01.setText(shuc);
                        ed01.setText("");
                    }
                };
                sc = ed01.getText().toString();
                if (sc.length() <= 0) {
                    pasteFromClip();
                }
                String endUrl = "https://xiaobeiit.cn/api/fy.php?t=de&w=" + Uri.encode(sc, "-![.:/,%?&=]");

                getAsync(endUrl, new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        Bundle bd = new Bundle();
                        bd.putString("content", failed);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                    }

                    @Override
                    public void onResponse(@Nullable Call call, @Nullable Response response) throws IOException {
                        assert response != null;
                        endStr = Objects.requireNonNull(response.body()).string();
                        Bundle bd = new Bundle();
                        bd.putString("content", endStr);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                        copyString(endStr);
                    }
                });
            }
        });

        btn28.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextHide(ed01);
                @SuppressLint("HandlerLeak") final Handler handler = new Handler() {
                    @Override
                    public void handleMessage(@NonNull Message msg) {
                        super.handleMessage(msg);
                        String shuc = Objects.requireNonNull(msg.getData().get("content")).toString();
                        shuc = shuc + "\n" + "\n" + sc;
                        tv01.setText(shuc);
                        ed01.setText("");
                    }
                };
                sc = ed01.getText().toString();
                if (sc.length() <= 0) {
                    pasteFromClip();
                }
                String endUrl = "https://xiaobeiit.cn/api/fy.php?t=ru&w=" + Uri.encode(sc, "-![.:/,%?&=]");

                getAsync(endUrl, new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        Bundle bd = new Bundle();
                        bd.putString("content", failed);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                    }

                    @Override
                    public void onResponse(@Nullable Call call, @Nullable Response response) throws IOException {
                        assert response != null;
                        endStr = Objects.requireNonNull(response.body()).string();
                        Bundle bd = new Bundle();
                        bd.putString("content", endStr);
                        Message message = new Message();
                        message.setData(bd);
                        handler.sendMessage(message);
                        copyString(endStr);
                    }
                });
            }
        });

        btn29.setOnClickListener(v -> {
            editTextHide(ed01);
            sc = ed01.getText().toString();
            if (sc.length() <= 0) {
                pasteFromClip();
            } else {
                copyString(sc);
            }
            scjump = "https://search.youku.com/search_video?keyword=" + sc;
            tv01.setText(sc);
            ed01.setText("");
            i.putExtra("jx", scjump);
            startActivity(i);
        });

        btn30.setOnClickListener(v -> {
            editTextHide(ed01);
            sc = ed01.getText().toString();
            if (sc.length() <= 0) {
                pasteFromClip();
            } else {
                copyString(sc);
            }
            scjump = "https://m.iqiyi.com/search.html?key=" + sc;
            tv01.setText(sc);
            ed01.setText("");
            i.putExtra("jx", scjump);
            startActivity(i);
        });

        btn31.setOnClickListener(v -> {
            editTextHide(ed01);
            sc = ed01.getText().toString();
            if (sc.length() <= 0) {
                pasteFromClip();
            } else {
                copyString(sc);
            }
            scjump = "https://m.v.qq.com/search.html?act=0&keyWord=" + sc;
            tv01.setText(sc);
            ed01.setText("");
            i.putExtra("jx", scjump);
            startActivity(i);
        });

        btn32.setOnClickListener(v -> {
            editTextHide(ed01);
            sc = ed01.getText().toString();
            if (sc.length() <= 0) {
                pasteFromClip();
            } else {
                copyString(sc);
            }
            scjump = "https://m.mgtv.com/so/?k=" + sc;
            tv01.setText(sc);
            ed01.setText("");
            i.putExtra("jx", scjump);
            startActivity(i);
        });
    }

    public void editTextHide(View ed01) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null && imm.isActive()) {
            imm.hideSoftInputFromWindow(ed01.getWindowToken(), 0);
            ed01.clearFocus();
        }
    }

    public void pasteFromClip() {
        ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (manager != null && manager.hasPrimaryClip()) {
            ClipData data = manager.getPrimaryClip();
            if (data != null) {
                CharSequence addedText = data.getItemAt(0).getText();
                sc = String.valueOf(addedText);
            }
        }
    }

    public void copyString(String copyStr) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData mClipData = ClipData.newPlainText("Label", copyStr);
        if (cm != null) {
            cm.setPrimaryClip(mClipData);
        }
    }

    public void joinQQGroup(String key) {
        Intent group = new Intent();
        group.setData(Uri.parse("mqqopensdkapi://bizAgent/qm/qr?url=http%3A%2F%2Fqm.qq.com%2Fcgi-bin%2Fqm%2Fqr%3Ffrom%3Dapp%26p%3Dandroid%26k%3D" + key));
        startActivity(group);
    }

    public static void getAsync(String url, Callback callback) {
        OkHttpClient client = new OkHttpClient().newBuilder().connectTimeout(5, TimeUnit.SECONDS).readTimeout(5, TimeUnit.SECONDS).proxy(Proxy.NO_PROXY).build();
        Request request = new Request.Builder().url(url).build();
        client.newCall(request).enqueue(callback);
    }
}