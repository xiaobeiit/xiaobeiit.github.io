package com.huidu.app;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import android.net.*;

public class MvWeb extends Activity
{
	private WebView wv;
	private String scUrl;
	@Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
		int option = getWindow().getDecorView().getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
        getWindow().getDecorView().setSystemUiVisibility(option);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
		setContentView(R.layout.mvview);
        wv = findViewById(R.id.webView);
        Button btn01 = findViewById(R.id.btn01);
        Button btn02 = findViewById(R.id.btn02);
        Button btn03 = findViewById(R.id.btn03);
        Button btn04 = findViewById(R.id.btn04);
        scJx();
		btn01.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					String jxone = "http://jsap.attakids.com/?url=" + wv.getUrl();
					Intent intent = new Intent(MvWeb.this, MvDesktop.class);
					intent.putExtra("jx", jxone);
					startActivity(intent);}});

		btn02.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					String jxtwo = "http://www.ckmov.com/?url=" + wv.getUrl();
					Intent intent = new Intent(MvWeb.this, MvDesktop.class);
					intent.putExtra("jx", jxtwo);
					startActivity(intent);}});

		btn03.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					String jxthree = "https://z1.m1907.cn/?jx=" + wv.getUrl();
					Intent intent = new Intent(MvWeb.this, WebActivity.class);
					intent.putExtra("jx", jxthree);
					startActivity(intent);}});

		btn04.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
					ClipData mClipData = ClipData.newPlainText("Label", wv.getUrl());
					cm.setPrimaryClip(mClipData);
				}});

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
		{
            wv.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
		}
		wv.setLayerType(View.LAYER_TYPE_HARDWARE, null);
		wv.setHorizontalScrollBarEnabled(false);
		wv.setVerticalScrollBarEnabled(false);
		wv.getSettings().setBuiltInZoomControls(false);
		wv.getSettings().setUseWideViewPort(true);
		wv.getSettings().setJavaScriptEnabled(true);
		wv.getSettings().setLoadWithOverviewMode(true);	
		wv.getSettings().setSupportZoom(true);
		wv.getSettings().setDomStorageEnabled(true);
		wv.setBackgroundColor(0);
		wv.getBackground().setAlpha(2);
		CookieSyncManager.createInstance(this);
		CookieManager cookieManager = CookieManager.getInstance();
		cookieManager.setAcceptCookie(true);
		CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true);
		wv.getSettings().setUserAgentString(wv.getSettings().getUserAgentString());
		wv.setWebViewClient(new WebViewClient(){
				@Override
				public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
					if (request.getUrl().toString().contains("woozoo") || request.getUrl().toString().contains("cnzz")){
						return new WebResourceResponse(null,null,null);
					}else{
						return super.shouldInterceptRequest(view,request);
					}
				}
				@Override
				public boolean shouldOverrideUrlLoading(WebView view, String url)
				{
					if (url.startsWith("imgotv") || url.startsWith("hntv") || url.startsWith("baidu"))
					{
					return true;
						}
					else
					{
					return false;
						}}
					});
			wv.setDownloadListener(new DownloadListener() {
		@Override
				public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength)
				{
				Intent i = new Intent(Intent.ACTION_VIEW);
					i.setData(Uri.parse(url));
					startActivity(i);
					}});	
				}
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
	{
	if (keyCode == KeyEvent.KEYCODE_BACK && wv.canGoBack())
		{
		wv.goBack();
            return true;
			}
        return super.onKeyDown(keyCode, event);
		}
    @Override
    protected void onDestroy()
	{
	if (wv != null)
		{
		wv.loadDataWithBaseURL(null, "", "text/html", "utf-8", null);
            wv.clearHistory();
            ((ViewGroup) wv.getParent()).removeView(wv);
            wv.destroy();
            wv = null;
			}
        super.onDestroy();
		}
    private void scJx()
	{
	scUrl = getIntent().getStringExtra("search");
	    wv.loadUrl(scUrl);}
		}
